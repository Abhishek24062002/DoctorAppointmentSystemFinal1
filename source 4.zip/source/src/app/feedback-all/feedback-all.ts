import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feedback-all',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './feedback-all.html',
  styleUrls: ['./feedback-all.css']
})
export class FeedbackAll implements OnInit {
  feedbacks: any[] = [];

  constructor(private http: HttpClient,private router: Router) {}

  ngOnInit(): void {
    this.http.get<any[]>('https://localhost:7164/api/Feedback/all').subscribe(data => {
      this.feedbacks = data;
    });
  }



  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}

