import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackAll } from './feedback-all';

describe('FeedbackAll', () => {
  let component: FeedbackAll;
  let fixture: ComponentFixture<FeedbackAll>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FeedbackAll]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FeedbackAll);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
