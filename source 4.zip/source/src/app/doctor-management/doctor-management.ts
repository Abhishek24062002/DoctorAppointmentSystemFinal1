import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctor-management',
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './doctor-management.html',
  styleUrl: './doctor-management.css'
})
export class DoctorManagement implements OnInit {
  doctors: any[] = [];
  searchName = '';
  searchLocation = '';
  searchSpeciality = '';

  // Register fields
  regName = '';
  regGender = '';
  regAge!: number;
  regLocation = '';
  regSpeciality = '';
  regEducation = '';
  regExperience!: number;

  registeredDoctorId!:number; // doctor id

  // Credential fields
  credDoctorId!: number;
  credEmail = '';
  credPassword = '';
  credRoleId = 2; // Assuming roleId for Doctor is 2

  // Edit fields
  selectedDoctor: any = null;
  updName = '';
  updGender = '';
  updAge!: number;
  updLocation = '';
  updSpeciality = '';
  updEducation = '';
  updExperience!: number;

  apiReg = 'https://localhost:7164/api/DoctorRegistration';
  apiSearch = 'https://localhost:7164/api/DoctorSearch';

  constructor(private http: HttpClient,private router: Router) {}

  ngOnInit(): void {
    this.loadDoctors();
  }

  loadDoctors(): void {
    this.http.get<any[]>(`${this.apiSearch}/admin/all`).subscribe(data => {
      this.doctors = data;
    });
  }

  searchDoctors(): void {
    let params = new HttpParams();
    if (this.searchName) params = params.set('name', this.searchName);
    if (this.searchLocation) params = params.set('location', this.searchLocation);
    if (this.searchSpeciality) params = params.set('speciality', this.searchSpeciality);

    this.http.get<any[]>(`${this.apiSearch}/search`, { params }).subscribe(data => {
      this.doctors = data;
    });
  }

  registerDoctor(): void {
    const body = {
      name: this.regName,
      gender: this.regGender,
      age: this.regAge,
      location: this.regLocation,
      speciality: this.regSpeciality,
      education: this.regEducation,
      experienceYears: this.regExperience
    };

    this.http.post(`${this.apiReg}/register`, body).subscribe((res: any) => {
      alert(res.message);
      this.registeredDoctorId = res.doctorId; // store the staffId here
      this.loadDoctors();
    });
  }

  provideCredential(): void {
    const body = {
      doctorId: this.credDoctorId,
      email: this.credEmail,
      password: this.credPassword,
      roleId: this.credRoleId
    };

    this.http.post(`${this.apiReg}/register-Doctor-credential`, body, { responseType: 'text' })
      .subscribe(msg => {
        alert(msg);
        this.credDoctorId = 0;
        this.credEmail = '';
        this.credPassword = '';
      });
  }

  editDoctor(doc: any): void {
    this.selectedDoctor = doc;
    this.updName = doc.name;
    this.updGender = doc.gender;
    this.updAge = doc.age;
    this.updLocation = doc.location;
    this.updSpeciality = doc.speciality;
    this.updEducation = doc.education;
    this.updExperience = doc.experienceYears;
  }

  updateDoctor(): void {
    const body = {
      name: this.updName,
      gender: this.updGender,
      age: this.updAge,
      location: this.updLocation,
      speciality: this.updSpeciality,
      education: this.updEducation,
      experienceYears: this.updExperience
    };

    this.http.put(`${this.apiReg}/${this.selectedDoctor.doctorId}`, body, { responseType: 'text' })
      .subscribe(msg => {
        alert(msg);
        this.loadDoctors();
        this.selectedDoctor = null;
      });
  }

  deleteDoctor(id: number): void {
    if (!confirm('Delete doctor permanently?')) return;

    this.http.delete(`${this.apiReg}/${id}`, { responseType: 'text' })
      .subscribe(msg => {
        alert(msg);
        this.loadDoctors();
      });
  }


  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}
