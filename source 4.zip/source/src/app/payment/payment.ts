
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgFor, CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-payment',
  imports: [CommonModule, HttpClientModule, NgFor,FormsModule],
  templateUrl: './payment.html',
  styleUrl: './payment.css'
})
export class Payment implements OnInit {
  payments: any[] = [];
  email: string = '';
  startDate: string = '';
  endDate: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.loadPayments();
  }

  loadPayments(): void {
    this.http.get<any[]>('https://localhost:7164/api/AdminPayment/payments')
      .subscribe(data => this.payments = data);
  }

  searchPayments(): void {
    const params: any = {};
    if (this.email) params.email = this.email;
    if (this.startDate) params.startDate = this.startDate;
    if (this.endDate) params.endDate = this.endDate;

    this.http.get<any[]>('https://localhost:7164/api/AdminPayment/payments/search', { params })
      .subscribe(data => this.payments = data);
  }

  logout(): void {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}
