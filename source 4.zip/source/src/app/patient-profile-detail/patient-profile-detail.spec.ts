import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientProfileDetail } from './patient-profile-detail';

describe('PatientProfileDetail', () => {
  let component: PatientProfileDetail;
  let fixture: ComponentFixture<PatientProfileDetail>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PatientProfileDetail]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientProfileDetail);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
