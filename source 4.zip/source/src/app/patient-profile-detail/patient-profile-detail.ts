import { Component } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-profile-detail',
  imports: [CommonModule, HttpClientModule, FormsModule],
  templateUrl: './patient-profile-detail.html',
  styleUrl: './patient-profile-detail.css'
})
export class PatientProfileDetail {
  patientProfileId!: number;
  profile: any = null;
  fetchAttempted: boolean = false;

  constructor(private http: HttpClient,private router: Router) {}

  fetchProfile(): void {
    this.fetchAttempted = true;
    if (!this.patientProfileId) return;
    this.http.get(`https://localhost:7164/api/Patient/${this.patientProfileId}`)
      .subscribe({
        next: data => this.profile = data,
        error: () => this.profile = null // handles 404 or network failure
      });
  }
  

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}
