import { Routes } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { Register } from './register/register';
import { Login } from './login/login';
import { ForgotPassword } from './forgot-password/forgot-password';
import { ResetPassword } from './reset-password/reset-password';
import { Patient } from './patient/patient';
import { Admin } from './admin/admin';
import { Staff } from './staff/staff';
import { Doctor } from './doctor/doctor';
import { AuthGuard } from './auth-guard';
import { RoleGuard } from './role-guard';
import { Unauthorized } from './unauthorized/unauthorized';
import { Payment } from './payment/payment';
import { Users } from './users/users';
import { DoctorManagement } from './doctor-management/doctor-management';
import { StaffManagement } from './staff-management/staff-management';
import { FeedbackAll } from './feedback-all/feedback-all';
import { MedicalHistoryDetail } from './medical-history-detail/medical-history-detail';
import { PatientProfileDetail } from './patient-profile-detail/patient-profile-detail';
import { PrescriptionDetail } from './prescription-detail/prescription-detail';
import { TodaysAppointments } from './todays-appointments/todays-appointments';
import { StaffOperations } from './staff-operations/staff-operations';
import { SearchDoctor } from './search-doctor/search-doctor';

export const routes: Routes = [
    { path: '', component: Dashboard }, // default route // canActivate: [AuthGuard]
    { path: 'register', component: Register },
    { path: 'login', component: Login },
    { path: 'forgot-password', component: ForgotPassword },
    { path: 'reset-password', component: ResetPassword },

    { 
    path: 'admin', 
    component: Admin, 
    canActivate: [RoleGuard], 
    data: { expectedRole: 'Admin' } 
  },


  {
    path: 'admin/payments',
    component: Payment
  },

  {
    path: 'admin/users',
    component: Users
  },

  {
    path: 'admin/doctor-management',
    component: DoctorManagement
  },

  {
    path: 'admin/staff-management',
    component: StaffManagement
  },

  {
    path: 'admin/feedback-all',
    component: FeedbackAll
  },

  // {
  //   path: 'admin',
  //   component: Admin,
  //   canActivate: [RoleGuard],
  //   data: { expectedRole: 'Admin' },
  //   children: [
  //     { path: 'payments', component: Payment }
  //   ]
  // },

  { 
    path: 'doctor', 
    component: Doctor, 
    canActivate: [RoleGuard], 
    data: { expectedRole: 'Doctor' } 
  },
  { 
    path: 'staff', 
    component: Staff, 
    canActivate: [RoleGuard], 
    data: { expectedRole: 'Staff' } 
  },

  {
    path: 'staff/feedback-all',
    component: FeedbackAll
  },

  {
    path: 'staff/medical-history-detail',
    component: MedicalHistoryDetail
  },

  {
    path: 'staff/patient-profile-detail',
    component: PatientProfileDetail
  },

  {
    path: 'staff/prescription-detail',
    component: PrescriptionDetail
  },

  {
    path: 'staff/todays-appointments',
    component: TodaysAppointments
  },

  {
    path: 'staff/staff-operations',
    component: StaffOperations
  },

  {
    path: 'staff/search-doctor',
    component: SearchDoctor
  },

  { 
    path: 'patient', 
    component: Patient, 
    canActivate: [RoleGuard], 
    data: { expectedRole: 'Patient' } 
  },

  { path: 'unauthorized', component: Unauthorized },


  { path: '**', redirectTo: '' }
  
];
