import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-users',
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './users.html',
  styleUrl: './users.css'
})
export class Users implements OnInit {
  users: any[] = [];
  emailSearch: string = '';
  roleSearch: string = '';
  selectedUser: any = null;

  fullName: string = '';
  gender: string = '';
  age: number | null = null;
  isActive: boolean = true;

  apiUrl: string = 'https://localhost:7164/api/AdminUser';

  constructor(private http: HttpClient,private router: Router) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.http.get<any[]>(`${this.apiUrl}/users`).subscribe(res => {
      this.users = res;
    });
  }

  searchUsers(): void {
    let params = new HttpParams();
    if (this.emailSearch) params = params.set('email', this.emailSearch);
    if (this.roleSearch) params = params.set('role', this.roleSearch);

    this.http.get<any[]>(`${this.apiUrl}/users/search`, { params }).subscribe(res => {
      this.users = res;
    });
  }

  populateEdit(user: any): void {
    this.selectedUser = user;
    this.fullName = user.fullName;
    this.gender = user.gender;
    this.age = user.age;
    this.isActive = user.isActive;
  }

  updateUser(): void {
    if (!this.selectedUser) return;

    const body = {
      fullName: this.fullName,
      gender: this.gender,
      age: this.age,
      isActive: this.isActive
    };

    this.http.put(`${this.apiUrl}/users/${this.selectedUser.userId}`, body, { responseType: 'text' })
      .subscribe(() => {
        alert('User updated successfully.');
        this.loadUsers();
        this.selectedUser = null;
      });
  }

  deleteUser(userId: string): void {
    if (!confirm('Are you sure you want to delete this user?')) return;

    this.http.delete(`${this.apiUrl}/users/${userId}`, { responseType: 'text' })
      .subscribe(() => {
        alert('User deleted successfully.');
        this.loadUsers();
      });
  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}
