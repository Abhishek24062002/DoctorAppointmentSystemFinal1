import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,HttpClientModule,RouterModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login implements OnInit {
  loginForm!: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {}

  goToHome(){
    this.router.navigate(['/']);
  }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
  if (this.loginForm.valid) {
    this.http.post<any>('https://localhost:7164/api/Auth/login', this.loginForm.value)
      .subscribe({
        next: res => {
          localStorage.setItem('token', res.token);

          // Decode JWT payload:
          const tokenPayload = JSON.parse(atob(res.token.split('.')[1]));
          console.log('Payload:', tokenPayload);
          const role = tokenPayload['role'];
          console.log('Role:', role);

          if (role === 'Patient') {
            this.router.navigate(['/patient']);
          } else if (role === 'Doctor') {
            this.router.navigate(['/doctor']);
          } else if (role === 'Staff') {
            this.router.navigate(['/staff']);
          } else if (role === 'Admin') {
            this.router.navigate(['/admin']);
          } else {
            alert('Unknown role');
            this.router.navigate(['/']);
          }
        },
        error: err => {
          console.error(err);
          alert('Login failed');
        }
      });
  }
}

}