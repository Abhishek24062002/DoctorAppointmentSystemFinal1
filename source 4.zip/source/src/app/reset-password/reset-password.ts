import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-reset-password',
  imports: [ReactiveFormsModule,HttpClientModule],
  templateUrl: './reset-password.html',
  styleUrl: './reset-password.css'
})
export class ResetPassword implements OnInit {
  resetForm!: FormGroup;
  token!: string | null;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}


  goToHome(){
    this.router.navigate(['/']);
  }

  ngOnInit(): void {
    this.token = this.route.snapshot.queryParamMap.get('token');
    this.resetForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
    if (this.resetForm.valid && this.token) {
      const payload = {
        token: this.token,
        newPassword: this.resetForm.value.newPassword
      };

      this.http.post<any>('https://localhost:7164/api/Auth/reset-password', payload)
        .subscribe({
          next: res => {
            alert(res.message);
            this.router.navigate(['/login']);
          },
          error: err => {
            console.error(err);
            alert('Reset failed');
          }
        });
    }
  }
}
