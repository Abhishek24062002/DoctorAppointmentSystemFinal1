import { Component } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-todays-appointments',
  imports: [CommonModule, HttpClientModule, RouterModule],
  templateUrl: './todays-appointments.html',
  styleUrl: './todays-appointments.css'
})
export class TodaysAppointments {
  appointments: any[] = [];
  fetchAttempted: boolean = false;

  apiUrl = 'https://localhost:7164/api/StaffAppointment/appointments/today';

  constructor(private http: HttpClient, private router: Router) {}

  fetchAppointments(): void {
    this.fetchAttempted = true;
    this.http.get<any[]>(this.apiUrl).subscribe({
      next: data => this.appointments = data,
      error: () => this.appointments = []
    });
  }

  logout(): void {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}

