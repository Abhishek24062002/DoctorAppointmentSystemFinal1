import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDoctor } from './search-doctor';

describe('SearchDoctor', () => {
  let component: SearchDoctor;
  let fixture: ComponentFixture<SearchDoctor>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchDoctor]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchDoctor);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
