import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpClient, HttpParams } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-search-doctor',
  imports: [CommonModule, HttpClientModule, FormsModule, RouterModule],
  templateUrl: './search-doctor.html',
  styleUrl: './search-doctor.css'
})
export class SearchDoctor implements OnInit {
  name: string = '';
  location: string = '';
  speciality: string = '';
  results: any[] = [];
  fetchAttempted: boolean = false;

  apiUrl = 'https://localhost:7164/api/DoctorSearch/search';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    // Automatically load all doctors when page opens
    this.search();
  }

  search(): void {
    this.fetchAttempted = true;
    let params = new HttpParams();
  
    if (this.name) params = params.set('name', this.name);
    if (this.location) params = params.set('location', this.location);
    if (this.speciality) params = params.set('speciality', this.speciality);
  
  
    this.http.get<any[]>(this.apiUrl, { params }).subscribe({
      next: data => this.results = data,
      error: err => {
        console.error('Search failed:', err);
        this.results = [];
      }
    });
  }
  
  logout(): void {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}

