import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule,HttpClientModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register implements OnInit {
  registerForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {}


  goToHome(){
    this.router.navigate(['/']);
  }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      age: [''],
      gender: [''],
      role: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      this.http.post('https://localhost:7164/api/Auth/register', this.registerForm.value)
        .subscribe({
          next: () => {
            alert('Registration successful');
            this.router.navigate(['/']);
          },
          error: err => {
            console.error(err);
            alert('Registration failed');
          }
        });
    }
  }
}



// Update the URL to match your backend API base URL (adjust port if needed).

