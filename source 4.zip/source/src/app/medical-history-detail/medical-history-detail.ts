import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-medical-history-detail',
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './medical-history-detail.html',
  styleUrl: './medical-history-detail.css'
})
export class MedicalHistoryDetail {
  patientProfileId!: number;
  medicalHistory: any[] = [];
  fetchAttempted: boolean = false;
  apiUrl = 'https://localhost:7164/api/medical-history';

  constructor(private http: HttpClient,private router: Router) {}

  fetchHistory(): void {
    this.fetchAttempted = true;
    if (!this.patientProfileId) return;

    this.http.get<any[]>(`${this.apiUrl}/${this.patientProfileId}`)
      .subscribe({
        next: data => this.medicalHistory = data,
        error: () => this.medicalHistory = [] // clear on error
      });
  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}

