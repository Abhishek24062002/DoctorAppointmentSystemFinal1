import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalHistoryDetail } from './medical-history-detail';

describe('MedicalHistoryDetail', () => {
  let component: MedicalHistoryDetail;
  let fixture: ComponentFixture<MedicalHistoryDetail>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MedicalHistoryDetail]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MedicalHistoryDetail);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
