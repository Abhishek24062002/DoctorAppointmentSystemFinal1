import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpClient, HttpParams } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-staff-management',
  imports: [CommonModule, HttpClientModule, FormsModule],
  templateUrl: './staff-management.html',
  styleUrl: './staff-management.css'
})
export class StaffManagement implements OnInit {
  // Register staff fields
  name = '';
  age!: number;
  gender = '';
  mobile = '';
  location = '';
  email = '';
  defaultPassword = '';

  registeredStaffId!: number; // newly registered ID


  // Assign doctor fields
  staffIdAssign!: number;
  doctorIdAssign!: number;

  // Update staff fields
  staffIdUpdate!: number;
  updName = '';
  updAge!: number;
  updGender = '';
  updMobile = '';
  updLocation = '';

  // Delete staff
  staffIdDelete!: number;

  apiUrl = 'https://localhost:7164/api/StaffManagement';

  constructor(private http: HttpClient,private router: Router) {}

  ngOnInit(): void {}

  registerStaff(): void {
    const dto = {
      name: this.name,
      age: this.age,
      gender: this.gender,
      mobile: this.mobile,
      location: this.location,
      email: this.email,
      defaultPassword: this.defaultPassword
    };
    this.http.post(`${this.apiUrl}/register`, dto).subscribe((res: any) => {
      alert(res.message);
      this.registeredStaffId = res.staffId; // store the staffId here
    });
  }

  assignDoctor(): void {
    const dto = {
      staffId: this.staffIdAssign,
      doctorId: this.doctorIdAssign
    };
    this.http.post(`${this.apiUrl}/assign-doctor`, dto).subscribe((res: any) => {
      alert(res.message);
    });
  }

  updateStaff(): void {
    const dto = {
      staffId: this.staffIdUpdate,
      name: this.updName,
      age: this.updAge,
      gender: this.updGender,
      mobile: this.updMobile,
      location: this.updLocation
    };
    this.http.put(`${this.apiUrl}/update`, dto, { responseType: 'text' }).subscribe(msg => {
      alert(msg);
    });
  }

  deleteStaff(): void {
    this.http.delete(`${this.apiUrl}/delete/${this.staffIdDelete}`, { responseType: 'text' })
      .subscribe(msg => {
        alert(msg);
      });
  }



  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}

