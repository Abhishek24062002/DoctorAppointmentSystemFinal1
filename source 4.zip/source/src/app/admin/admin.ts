import { Component } from '@angular/core';
import {  Router, RouterModule } from '@angular/router'

@Component({
  selector: 'app-admin',
  imports: [RouterModule],
  templateUrl: './admin.html',
  styleUrl: './admin.css'
})
export class Admin {


  constructor( private router: Router) {}

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

}
