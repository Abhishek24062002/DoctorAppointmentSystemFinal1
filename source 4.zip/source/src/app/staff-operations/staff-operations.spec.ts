import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffOperations } from './staff-operations';

describe('StaffOperations', () => {
  let component: StaffOperations;
  let fixture: ComponentFixture<StaffOperations>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StaffOperations]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffOperations);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
