import { Component } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-staff-operations',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule, RouterModule],
  templateUrl: './staff-operations.html',
  styleUrl: './staff-operations.css'
})
export class StaffOperations {
  // Reschedule
  appointmentId!: number;
  newDate!: string;
  newTimeSlot = '';

  // Complete
  completeAppointmentId!: number;

  // Availability
  doctorId!: number;
  isAvailable: boolean = true;

  apiBase = 'https://localhost:7164/api/StaffAppointment';

  constructor(private http: HttpClient, private router: Router) {}

  reschedule(): void {
    const params = new HttpParams()
      .set('appointmentId', this.appointmentId)
      .set('newDate', this.newDate)
      .set('newTimeSlot', this.newTimeSlot);

    this.http.post(`${this.apiBase}/appointments/reschedule`, null, { params, responseType: 'text' })
      .subscribe(msg => alert(msg));
  }

  complete(): void {
    this.http.post(`${this.apiBase}/appointments/complete/${this.completeAppointmentId}`, null, { responseType: 'text' })
      .subscribe(msg => alert(msg));
  }

  // updateAvailability(): void {
  //   const body = { isAvailable: this.isAvailable };
  //   this.http.put(`${this.apiBase}/doctor/${this.doctorId}/availability`, body, { responseType: 'text' })
  //     .subscribe(msg => alert(msg));
  // }

  updateAvailability(): void {
    const body = { isAvailable: this.isAvailable };
    const headers = { 'Content-Type': 'application/json' };
  
    this.http.put(`${this.apiBase}/doctor/${this.doctorId}/availability`, body, {
      headers,
      responseType: 'text'
    }).subscribe({
      next: msg => alert(msg),
      error: err => console.error('Update failed:', err)
    });
  }
  

  logout(): void {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}

