import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-staff',
  imports: [RouterModule],
  templateUrl: './staff.html',
  styleUrl: './staff.css'
})
export class Staff {

  constructor( private router: Router) {}

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

}
