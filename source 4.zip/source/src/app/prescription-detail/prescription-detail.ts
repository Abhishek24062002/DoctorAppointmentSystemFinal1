import { Component } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-prescription-detail',
  imports: [CommonModule, HttpClientModule, FormsModule, RouterModule],
  templateUrl: './prescription-detail.html',
  styleUrl:'./prescription-detail.css'
})
export class PrescriptionDetail {
  patientProfileId!: number;
  prescriptions: any[] = [];
  fetchAttempted: boolean = false;

  apiUrl = 'https://localhost:7164/api/Prescription/prescription/patient';

  constructor(private http: HttpClient, private router: Router) {}

  fetchPrescriptions(): void {
    this.fetchAttempted = true;
    if (!this.patientProfileId) return;

    this.http.get<any[]>(`${this.apiUrl}/${this.patientProfileId}`)
      .subscribe({
        next: data => this.prescriptions = data,
        error: () => this.prescriptions = []
      });
  }

  logout(): void {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}

