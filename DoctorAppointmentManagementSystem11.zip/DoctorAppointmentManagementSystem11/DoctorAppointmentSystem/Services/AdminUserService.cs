﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public  class AdminUserService : IAdminUserService
    {

        private readonly AppDbContext _ctx;

        public AdminUserService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _ctx.Users.Include(u => u.Role).ToListAsync();
        }

        public async Task<User> GetUserByIdAsync(Guid userId)
        {
            return await _ctx.Users
                .Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.UserId == userId);
        }

        public async Task<bool> UpdateUserAsync(Guid userId, UserUpdateDto dto)
        {
            var user = await _ctx.Users.FindAsync(userId);
            if (user == null) return false;

            user.FullName = dto.FullName ?? user.FullName;
            user.Gender = dto.Gender ?? user.Gender;
            user.Age = dto.Age ?? user.Age;
            user.IsActive = dto.IsActive;

            _ctx.Users.Update(user);
            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteUserAsync(Guid userId)
        {
            var user = await _ctx.Users.FindAsync(userId);
            if (user == null) return false;

            _ctx.Users.Remove(user);
            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<List<User>> SearchUsersAsync(string? email, string? role)
        {
            var query = _ctx.Users.Include(u => u.Role).AsQueryable();

            if (!string.IsNullOrWhiteSpace(email))
                query = query.Where(u => u.Email.Contains(email));

            if (!string.IsNullOrWhiteSpace(role))
                query = query.Where(u => u.Role.Name == role);

            return await query.ToListAsync();
        }

    }
}
