﻿using System.Net;
using System.Net.Mail;
using DoctorAppointmentSystem.IServices;
using Microsoft.Extensions.Configuration;

namespace DoctorAppointment.Repo
{
    public class EmailSender : IEmailSender
    {
        private readonly IConfiguration _config;
        public EmailSender(IConfiguration config) => _config = config;

        public async Task SendEmailAsync(string to, string subject, string htmlMessage)
        {
            var smtpHost = _config["Smtp:Host"];
            var smtpPort = int.Parse(_config["Smtp:Port"]);
            var from = _config["Smtp:From"];
            var username = _config["Smtp:Username"];
            var password = _config["Smtp:Password"];

            using var smtp = new SmtpClient(smtpHost)
            {
                Port = smtpPort,
                Credentials = new NetworkCredential(username, password),
                EnableSsl = true
            };

            var mail = new MailMessage(from, to, subject, htmlMessage)
            {
                IsBodyHtml = true
            };

            await smtp.SendMailAsync(mail);
        }
    }
}
