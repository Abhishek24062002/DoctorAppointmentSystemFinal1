﻿using DoctorAppointmentSystem.IServices;

namespace DoctorAppointmentSystem.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IAppointmentService _appointment;
        public PaymentService(IAppointmentService appointment)
        {
            _appointment = appointment;
        }

        public async Task<bool> ProcessPaymentAsync(int appointmentId, decimal amount)
        {
            // Simulate a successful payment
            var success = await _appointment.MarkAsPaidAsync(appointmentId);
            return success;
        }
    }

}
