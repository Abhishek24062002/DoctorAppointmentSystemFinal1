﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public class AdminPaymentService : IAdminPaymentService
    {
        public readonly AppDbContext _ctx;

        public AdminPaymentService(AppDbContext appDbContext) => _ctx = appDbContext;


        public async Task<List<PaymentDto>> GetAllPaymentsAsync()
        {
            var payments = await _ctx.Appointments
                .Include(a => a.PatientProfile)
                    .ThenInclude(p => p.User)
                .Where(a => a.IsPaid == true)
                .Select(a => new PaymentDto
                {
                    UserId = a.PatientProfile.User.UserId,
                    UserFullName = a.PatientProfile.User.FullName,
                    UserEmail = a.PatientProfile.User.Email,

                    PatientProfileId = a.PatientProfileId,
                    PatientName = a.PatientProfile.Name,

                    AppointmentId = a.AppointmentId,
                    AppointmentDate = a.Date,
                    TimeSlot = a.TimeSlot,

                    Amount = a.Fee,
                    IsPaid = a.IsPaid
                })
                .ToListAsync();

            return payments;
        }


        public async Task<List<PaymentDto>> SearchPaymentsAsync(string? email, DateTime? startDate, DateTime? endDate)
        {
            var query = _ctx.Appointments
                .Include(a => a.PatientProfile)
                    .ThenInclude(p => p.User)
                .Where(a => a.IsPaid == true)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(email))
            {
                query = query.Where(a => a.PatientProfile.User.Email.Contains(email));
            }

            if (startDate.HasValue)
            {
                query = query.Where(a => a.Date >= startDate.Value.Date);
            }

            if (endDate.HasValue)
            {
                query = query.Where(a => a.Date <= endDate.Value.Date);
            }

            return await query.Select(a => new PaymentDto
            {
                UserId = a.PatientProfile.User.UserId,
                UserFullName = a.PatientProfile.User.FullName,
                UserEmail = a.PatientProfile.User.Email,

                PatientProfileId = a.PatientProfileId,
                PatientName = a.PatientProfile.Name,

                AppointmentId = a.AppointmentId,
                AppointmentDate = a.Date,
                TimeSlot = a.TimeSlot,

                Amount = a.Fee,
                IsPaid = a.IsPaid
            }).ToListAsync();
        }




    }

}
