﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public class PrescriptionService : IPrescriptionService
    {

        private readonly AppDbContext _ctx;

        public PrescriptionService(AppDbContext ctx)
        {
            _ctx = ctx;
        }


        //Prescription

        public async Task<int> CreatePrescriptionAsync(CreatePrescriptionDto dto, int doctorId)
        {
            var doctor = await _ctx.Doctors.FindAsync(doctorId);
            var patient = await _ctx.PatientProfiles.FindAsync(dto.PatientProfileId);

            if (doctor == null || patient == null)
                throw new Exception("Invalid doctor or patient");

            var prescription = new Prescription
            {
                UserId = dto.UserId,
                PatientProfileId = dto.PatientProfileId,
                DoctorId = doctorId,
                AppointmentId = dto.AppointmentId,
                Notes = dto.Notes
            };

            _ctx.Prescriptions.Add(prescription);
            await _ctx.SaveChangesAsync();

            return prescription.PrescriptionId;
        }

        public async Task<List<Prescription>> GetPrescriptionsByPatientIdAsync(int patientProfileId)
        {
            return await _ctx.Prescriptions
                .Include(p => p.Doctor)
                .Include(p => p.PatientProfile)
                .Where(p => p.PatientProfileId == patientProfileId)
                .ToListAsync();
        }

        public async Task<List<Prescription>> GetPrescriptionsByAppointmentIdAsync(int appointmentId)
        {
            return await _ctx.Prescriptions
                .Include(p => p.Doctor)
                .Include(p => p.PatientProfile)
                .Where(p => p.AppointmentId == appointmentId)
                .ToListAsync();
        }

        public async Task<List<Prescription>> GetAllPrescriptionsForDoctorAsync(int doctorId)
        {
            return await _ctx.Prescriptions
                .Include(p => p.PatientProfile)
                .Where(p => p.DoctorId == doctorId)
                .ToListAsync();
        }
    }
}
