﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Configuration;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.DTOs;

namespace DoctorAppointmentSystem.Repository
{
    public class AuthService : IAuthService
    {
        private readonly AppDbContext _ctx;
        private readonly IConfiguration _config;
        public AuthService(AppDbContext ctx, IConfiguration config)
        {
            _ctx = ctx; _config = config;
        }

      

        public async Task RegisterAsync(DoctorAppointmentSystem.DTOs.RegisterRequest model)
        {
            if (await _ctx.Users.AnyAsync(u => u.Email == model.Email))
                throw new Exception("Email already in use.");

            var role = await _ctx.Roles.SingleOrDefaultAsync(r => r.Name == model.Role);
            if (role == null) throw new Exception("Invalid role.");

            var pwdHash = BCrypt.Net.BCrypt.HashPassword(model.Password);
            var user = new User
            {
                FullName = model.FullName,
                Email = model.Email,
                Age = model.Age,
                Gender = model.Gender,
                PasswordHash = pwdHash,
                RoleId = role.RoleId
            };
            _ctx.Users.Add(user);
            await _ctx.SaveChangesAsync();
        }

        public async Task<string> LoginAsync(LoginRequest model)
        {
            var user = await _ctx.Users
                .Include(u => u.Role)
                .SingleOrDefaultAsync(u => u.Email == model.Email);

            if (user == null || !BCrypt.Net.BCrypt.Verify(model.Password, user.PasswordHash))
                throw new Exception("Invalid credentials.");
            if (!user.IsActive)
                throw new Exception("User inactive.");

            var claims = new List<Claim>
    {
        new Claim(JwtRegisteredClaimNames.Sub, user.UserId.ToString()),
        new Claim("email", user.Email),
        new Claim("role", user.Role.Name),
        new Claim(ClaimTypes.Role, user.Role.Name)
    };

            // ✅ Include DoctorId if role is Doctor
            if (user.Role.Name == "Doctor")
            {
                var doctorCredential = await _ctx.DoctorCredentials
                    .SingleOrDefaultAsync(dc => dc.Email == user.Email);

                if (doctorCredential != null)
                {
                    claims.Add(new Claim("DoctorId", doctorCredential.DoctorId.ToString()));
                }
            }


            if (user.Role.Name == "Staff")
            {
                var cred = await _ctx.StaffCredentials.SingleOrDefaultAsync(s => s.Email == user.Email);
                if (cred != null)
                    claims.Add(new Claim("StaffId", cred.StaffId.ToString()));
            }


            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(int.Parse(_config["Jwt:DurationMinutes"])),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }



    }

}
