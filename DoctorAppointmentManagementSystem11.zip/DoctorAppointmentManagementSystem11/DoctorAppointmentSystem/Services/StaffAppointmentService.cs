﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public class StaffAppointmentService : IStaffAppointmentService
    {
        private readonly AppDbContext _ctx;
        public StaffAppointmentService(AppDbContext ctx) => _ctx = ctx;

        public async Task<bool> RescheduleAppointmentAsync(int appointmentId, DateTime newDate, string newTimeSlot)
        {
            var ap = await _ctx.Appointments.FindAsync(appointmentId);
            if (ap == null) return false;
            ap.Date = newDate;
            ap.TimeSlot = newTimeSlot;
            ap.Status = "Rescheduled";
            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<bool> MarkAppointmentCompletedAsync(int appointmentId)
        {
            var ap = await _ctx.Appointments.FindAsync(appointmentId);
            if (ap == null) return false;
            ap.Status = "Completed";
            await _ctx.SaveChangesAsync();
            return true;
        }


       

        public async Task<List<Appointment>> GetTodaysAppointmentsForStaffAsync(int staffId)
        {
            var doctorIds = await _ctx.StaffDoctorMaps
                .Where(sd => sd.StaffId == staffId)
                .Select(sd => sd.DoctorId)
                .ToListAsync();

            return await _ctx.Appointments
                .Include(a => a.PatientProfile)
                .Include(a => a.Doctor)
                .Where(a => doctorIds.Contains(a.DoctorId) && a.Date.Date == DateTime.Today)
                .ToListAsync();
        }

        public async Task<bool> UpdateDoctorAvailabilityAsync(int doctorId, bool isAvailable)
        {
            var doctor = await _ctx.Doctors.FindAsync(doctorId);
            if (doctor == null) return false;

            doctor.IsAvailable = isAvailable;
            _ctx.Doctors.Update(doctor);
            await _ctx.SaveChangesAsync();
            return true;
        }



    }

}


