﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public class DoctorSearchService : IDoctorSearchService
    {
        private readonly AppDbContext _ctx;
        public DoctorSearchService(AppDbContext ctx)
        {
            _ctx = ctx;
        }
        public async Task<List<Doctor>> GetAllDoctorsAsync()
        {
            return await _ctx.Doctors.ToListAsync();
        }

        public async Task<Doctor> GetDoctorByIdAsync(int id)
        {
            return await _ctx.Doctors.FindAsync(id);
        }

        public async Task<List<Doctor>> SearchDoctorsAsync(string name, string location, string speciality)
        {
            var query = _ctx.Doctors.AsQueryable();

            if (!string.IsNullOrWhiteSpace(name))
                query = query.Where(d => d.Name.Contains(name));

            if (!string.IsNullOrWhiteSpace(location))
                query = query.Where(d => d.Location.Contains(location));

            if (!string.IsNullOrWhiteSpace(speciality))
                query = query.Where(d => d.Speciality.Contains(speciality));

            return await query.ToListAsync();
        }



    }
}
