﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public class StaffManagementService : IStaffManagementService
    {

        private readonly AppDbContext _ctx;

        public StaffManagementService(AppDbContext ctx) => _ctx = ctx;


        public async Task<int> RegisterStaffAsync(StaffRegisterDto dto)
        {
            var staff = new Staff
            {
                Name = dto.Name,
                Age = dto.Age,
                Gender = dto.Gender,
                Mobile = dto.Mobile,
                Location = dto.Location
            };
            _ctx.Staffs.Add(staff);
            await _ctx.SaveChangesAsync();

            _ctx.StaffCredentials.Add(new StaffCredential
            {
                StaffId = staff.StaffId,
                Email = dto.Email
            });

            var doctorRole = await _ctx.Roles.FirstOrDefaultAsync(r => r.Name == "Staff");
            if (doctorRole == null) throw new Exception("Staff role missing.");

            _ctx.Users.Add(new User
            {
                UserId = Guid.NewGuid(),
                FullName = dto.Name,
                Email = dto.Email,
                Age = dto.Age,
                Gender = dto.Gender,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.DefaultPassword),
                RoleId = doctorRole.RoleId,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            });

            await _ctx.SaveChangesAsync();
            return staff.StaffId;
        }


        public async Task<bool> AssignDoctorToStaffAsync(int staffId, int doctorId)
        {
            var exists = await _ctx.StaffDoctorMaps
                .AnyAsync(m => m.StaffId == staffId && m.DoctorId == doctorId);

            if (exists) return false;

            var doctorExists = await _ctx.Doctors.AnyAsync(d => d.DoctorId == doctorId);
            var staffExists = await _ctx.Staffs.AnyAsync(s => s.StaffId == staffId);

            if (!doctorExists || !staffExists) return false;

            _ctx.StaffDoctorMaps.Add(new StaffDoctorMap
            {
                StaffId = staffId,
                DoctorId = doctorId
            });

            await _ctx.SaveChangesAsync();
            return true;
        }



        public async Task<bool> UpdateStaffAsync(StaffUpdateDto dto)
        {
            var staff = await _ctx.Staffs.FindAsync(dto.StaffId);
            if (staff == null) return false;
            if (!string.IsNullOrEmpty(dto.Name)) staff.Name = dto.Name;
            staff.Age = dto.Age ?? staff.Age;
            if (!string.IsNullOrEmpty(dto.Gender)) staff.Gender = dto.Gender;
            if (!string.IsNullOrEmpty(dto.Mobile)) staff.Mobile = dto.Mobile;
            if (!string.IsNullOrEmpty(dto.Location)) staff.Location = dto.Location;
            await _ctx.SaveChangesAsync();
            return true;
        }
        public async Task<bool> DeleteStaffAsync(int staffId)
        {
            var staff = await _ctx.Staffs.FindAsync(staffId);
            if (staff == null) return false;
            var cred = await _ctx.StaffCredentials.FindAsync(staffId);
            if (cred != null) _ctx.StaffCredentials.Remove(cred);
            var user = await _ctx.Users.SingleOrDefaultAsync(u => u.Email == cred.Email);
            if (user != null) _ctx.Users.Remove(user);
            _ctx.Staffs.Remove(staff);
            await _ctx.SaveChangesAsync();
            return true;
        }

       

       
    }
}
