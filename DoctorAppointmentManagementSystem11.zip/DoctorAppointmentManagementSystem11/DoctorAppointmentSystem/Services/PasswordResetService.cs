﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using DoctorAppointmentSystem.IServices;
namespace DoctorAppointment.Repo
{
    public class PasswordResetService : IPasswordResetService
    {
        private readonly AppDbContext _ctx;
        private readonly IEmailSender _emailSender; // Fully qualify the namespace to resolve ambiguity
        private readonly IConfiguration _config;
        public PasswordResetService(AppDbContext ctx, IEmailSender emailSender, IConfiguration config)
        {
            _ctx = ctx;
            _emailSender = emailSender;
            _config = config;
        }

        public async Task<string> RequestPasswordResetAsync(string email, string origin)
        {
            var user = await _ctx.Users.SingleOrDefaultAsync(u => u.Email == email);
            if (user == null) return null;

            var plainToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
            var hashedToken = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(plainToken)));

            var reset = new UserPasswordReset
            {
                UserId = user.UserId,
                Token = hashedToken,
                ExpiresAt = DateTime.UtcNow.AddHours(1),
                IsUsed = false
            };

            _ctx.UserPasswordResets.Add(reset);
            await _ctx.SaveChangesAsync();

            var resetUrl = $"{origin}/reset-password?token={WebUtility.UrlEncode(plainToken)}";

            await _emailSender.SendEmailAsync(user.Email, "Reset Your Password",
                $"Click <a href=\"{resetUrl}\">here</a> to reset your password. This link will expire in 1 hour.");

            return plainToken; // ← return plain token for testing
        }


        public async Task ResetPasswordAsync(ResetPasswordRequest model)
        {
            // hash submitted token
            var hashed = SHA256.HashData(Encoding.UTF8.GetBytes(model.Token));
            var hashString = Convert.ToHexString(hashed);

            var entry = await _ctx.UserPasswordResets
                .Include(r => r.User)
                .Where(r => r.Token == hashString && !r.IsUsed && r.ExpiresAt >= DateTime.UtcNow)
                .FirstOrDefaultAsync();

            if (entry == null) throw new Exception("Invalid or expired token.");

            // update password
            entry.IsUsed = true;
            entry.UsedAt = DateTime.UtcNow;
            entry.User.PasswordHash = BCrypt.Net.BCrypt.HashPassword(model.NewPassword);
            await _ctx.SaveChangesAsync();
        }
    }

}
