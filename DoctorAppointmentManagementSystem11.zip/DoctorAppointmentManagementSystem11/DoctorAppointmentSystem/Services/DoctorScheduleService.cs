﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public class DoctorScheduleService : IDoctorScheduleService
    {
        private readonly AppDbContext _ctx;

        public DoctorScheduleService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<DoctorWithSlotsDto> GetDoctorByIdWithSlotsAsync(int id)
        {
            var doctor = await _ctx.Doctors
                .Include(d => d.TimeSlots)
                .FirstOrDefaultAsync(d => d.DoctorId == id);

            if (doctor == null) return null;

            return new DoctorWithSlotsDto
            {
                DoctorId = doctor.DoctorId,
                Name = doctor.Name,
                Speciality = doctor.Speciality,
                IsAvailable = doctor.TimeSlots.Any(ts => ts.IsAvailable),
                TimeSlots = doctor.TimeSlots
                    .Select(ts => new TimeSlotDto
                    {
                        Slot = ts.TimeSlot,
                        IsAvailable = ts.IsAvailable
                    }).ToList()
            };
        }






        public async Task AddTimeSlotsAsync(int doctorId, List<CreateDoctorTimeSlotDto> slots)
        {
            var doctor = await _ctx.Doctors.FindAsync(doctorId);
            if (doctor == null) throw new Exception("Doctor not found");

            var timeSlots = slots.Select(s => new DoctorTimeSlot
            {
                DoctorId = doctorId,
                TimeSlot = s.TimeSlot,
                IsAvailable = s.IsAvailable
            }).ToList();

            _ctx.DoctorTimeSlots.AddRange(timeSlots);
            await _ctx.SaveChangesAsync();
        }

        public async Task<List<DoctorTimeSlot>> GetOwnTimeSlotsAsync(int doctorId)
        {
            return await _ctx.DoctorTimeSlots
                .Where(ts => ts.DoctorId == doctorId)
                .ToListAsync();
        }

        public async Task<bool> UpdateTimeSlotAvailabilityAsync(int doctorId, UpdateDoctorTimeSlotDto dto)
        {
            var slot = await _ctx.DoctorTimeSlots
                .FirstOrDefaultAsync(ts => ts.DoctorTimeSlotId == dto.DoctorTimeSlotId && ts.DoctorId == doctorId);

            if (slot == null) return false;

            slot.IsAvailable = dto.IsAvailable;
            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteTimeSlotAsync(int doctorId, int slotId)
        {
            var slot = await _ctx.DoctorTimeSlots
                .FirstOrDefaultAsync(ts => ts.DoctorTimeSlotId == slotId && ts.DoctorId == doctorId);

            if (slot == null) return false;

            _ctx.DoctorTimeSlots.Remove(slot);
            await _ctx.SaveChangesAsync();
            return true;
        }

    }
}
