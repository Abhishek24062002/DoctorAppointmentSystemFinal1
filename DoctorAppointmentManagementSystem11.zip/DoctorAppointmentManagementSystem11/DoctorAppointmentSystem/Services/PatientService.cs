﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;



namespace DoctorAppointmentSystem.Services
{
    public class PatientService : IPatientService
    {
        private readonly AppDbContext _ctx;
        private readonly IWebHostEnvironment _env;

        public PatientService(AppDbContext ctx, IWebHostEnvironment env)
        {
            _ctx = ctx;
            _env = env;
        }

        public async Task<int> CreatePatientProfileAsync(PatientProfileDto dto, IFormFile medicalHistoryPdf, Guid userId)
        {
            string relativePath = null;

            try
            {
                if (medicalHistoryPdf != null && medicalHistoryPdf.Length > 0)
                {
                    var fileExtension = Path.GetExtension(medicalHistoryPdf.FileName);

                    if (string.IsNullOrWhiteSpace(fileExtension) || fileExtension.ToLower() != ".pdf")
                        throw new InvalidOperationException("Only PDF files are allowed.");

                    var webRootPath = _env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
                    var uploadsFolder = Path.Combine(webRootPath, "uploads");

                    Directory.CreateDirectory(uploadsFolder); // Ensure uploads folder exists

                    var uniqueFileName = Guid.NewGuid().ToString() + ".pdf";
                    var fullFilePath = Path.Combine(uploadsFolder, uniqueFileName);
                    relativePath = Path.Combine("uploads", uniqueFileName).Replace("\\", "/");

                    using var stream = new FileStream(fullFilePath, FileMode.Create);
                    await medicalHistoryPdf.CopyToAsync(stream);
                }
            }
            catch (Exception ex)
            {
                // Optional: log error via ILogger
                Console.WriteLine($"File upload failed: {ex.Message}");
                relativePath = null;
            }

            var profile = new PatientProfile
            {
                UserId = userId,
                Name = dto.Name,
                Age = dto.Age,
                Gender = dto.Gender,
                Address = dto.Address,
                Mobile = dto.Mobile,
                BloodGroup = dto.BloodGroup,
                MedicalHistoryPath = relativePath
            };

            _ctx.PatientProfiles.Add(profile);
            await _ctx.SaveChangesAsync();

            return profile.PatientProfileId;
        }

        public async Task<List<PatientProfile>> GetAllProfilesAsync()
            => await _ctx.PatientProfiles.ToListAsync();

        public async Task<PatientProfile> GetProfileByIdAsync(int id)
            => await _ctx.PatientProfiles.FindAsync(id);
    }
}
