﻿
using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.DTOs.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DoctorAppointmentSystem.Services
{
    public class AppointmentService : IAppointmentService
    {
        private readonly AppDbContext _ctx;

        public AppointmentService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        /*
        public async Task<int> BookAppointmentAsync(CreateAppointmentDto dto)
        {
            // ✅ Check if doctor exists and is available
            var doctor = await _ctx.Doctors.FindAsync(dto.DoctorId);
            if (doctor == null)
                throw new InvalidOperationException("Doctor not found.");

            if (!doctor.IsAvailable)
                throw new InvalidOperationException("Doctor is currently unavailable for appointments.");

            // ✅ Check if daily slot limit (e.g. 12) is reached
            var countToday = await _ctx.Appointments
                .CountAsync(a =>
                    a.DoctorId == dto.DoctorId &&
                    a.Date.Date == dto.Date.Date &&
                    (a.Status == "Booked" || a.Status == "Confirmed")
                );

            if (countToday >= 12)
                throw new InvalidOperationException("Appointments full, please reschedule.");

            // ✅ Proceed with booking
            var appointment = new Appointment
            {
                PatientProfileId = dto.PatientProfileId,
                DoctorId = dto.DoctorId,
                Date = dto.Date,
                TimeSlot = dto.TimeSlot,
                Status = "Pending",
                Fee = dto.Fee
            };

            _ctx.Appointments.Add(appointment);
            await _ctx.SaveChangesAsync();

            return appointment.AppointmentId;
        }
        */

        public async Task<int> BookAppointmentAsync(CreateAppointmentDto dto)
        {
            // ✅ Check if doctor exists
            var doctor = await _ctx.Doctors
                .Include(d => d.TimeSlots)
                .FirstOrDefaultAsync(d => d.DoctorId == dto.DoctorId);

            if (doctor == null)
                throw new InvalidOperationException("Doctor not found.");

            // ✅ Check if the selected timeslot exists for this doctor
            var selectedSlot = doctor.TimeSlots
                .FirstOrDefault(ts => ts.TimeSlot == dto.TimeSlot);

            if (selectedSlot == null)
                throw new InvalidOperationException("This time slot is not configured for the doctor.");

            // ✅ Check if the doctor is available at that timeslot
            if (!selectedSlot.IsAvailable)
                throw new InvalidOperationException("Doctor is not available at this time slot.");

            // ✅ Check if the max 5 appointments for this slot on the date is reached
            var existingCount = await _ctx.Appointments.CountAsync(a =>
                a.DoctorId == dto.DoctorId &&
                a.Date.Date == dto.Date.Date &&
                a.TimeSlot == dto.TimeSlot &&
                (a.Status == "Booked" || a.Status == "Confirmed" || a.Status == "Pending"));

            if (existingCount >= 5)
                throw new InvalidOperationException("This time slot is fully booked. Please select another slot.");

            // ✅ Proceed with booking
            var appointment = new Appointment
            {
                PatientProfileId = dto.PatientProfileId,
                DoctorId = dto.DoctorId,
                Date = dto.Date,
                TimeSlot = dto.TimeSlot,
                Status = "Pending",
                Fee = dto.Fee
            };

            _ctx.Appointments.Add(appointment);
            await _ctx.SaveChangesAsync();

            return appointment.AppointmentId;
        }



        public async Task<List<Appointment>> GetAppointmentsByPatientId(int patientId)
        {
            return await _ctx.Appointments
                .Include(a => a.Doctor)
                .Where(a => a.PatientProfileId == patientId)
                .ToListAsync();
        }


        public async Task<PatientProfile> GetPatientProfileByUserIdAsync(string userId)
        {
            if (!Guid.TryParse(userId, out Guid parsedUserId))
                return null; // or throw an error if you prefer

            return await _ctx.PatientProfiles.FirstOrDefaultAsync(p => p.UserId == parsedUserId);
        }


        public async Task<List<Appointment>> GetAllAppointmentsAsync()
        {
            return await _ctx.Appointments
                .Include(a => a.Doctor)
                .Include(a => a.PatientProfile)
                .ToListAsync();
        }


        public async Task<bool> RescheduleAsync(RescheduleAppointmentDto dto)
        {
            var appointment = await _ctx.Appointments.FindAsync(dto.AppointmentId);
            if (appointment == null) return false;

            appointment.Date = dto.NewDate;
            appointment.TimeSlot = dto.NewTimeSlot;
            appointment.Status = "Rescheduled";

            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<bool> CancelAsync(int appointmentId)
        {
            var appointment = await _ctx.Appointments.FindAsync(appointmentId);
            if (appointment == null) return false;

            appointment.Status = "Cancelled";
            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<bool> MarkAsPaidAsync(int appointmentId)
        {
            var appointment = await _ctx.Appointments.FindAsync(appointmentId);
            if (appointment == null || appointment.Status == "Cancelled") return false;

            appointment.IsPaid = true;
            appointment.Status = "Booked";
            await _ctx.SaveChangesAsync();
            return true;
        }


    }

}
