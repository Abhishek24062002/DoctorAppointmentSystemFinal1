﻿namespace DoctorAppointmentSystem.Models
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public Guid UserId { get; set; }
        public User User { get; set; }
        public int PatientProfileId { get; set; }
        public PatientProfile PatientProfile { get; set; }
        public int AppointmentId { get; set; }
        public Appointment Appointment { get; set; }
        public decimal Amount { get; set; }
        public bool IsPaid { get; set; }
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
    }

}
