﻿namespace DoctorAppointmentSystem.Models
{
    public class Staff
    {
        public int StaffId { get; set; }
        public string Name { get; set; }
        public int? Age { get; set; }
        public string Gender { get; set; }
        public string Mobile { get; set; }
        public string Location { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

}
