﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoctorAppointmentSystem.Models
{
    public class DoctorCredential
    {
        [Key]
        public int DoctorId { get; set; }

        [Required]
        public string Email { get; set; }

        [ForeignKey("DoctorId")]
        public Doctor Doctor { get; set; }
    }

}
