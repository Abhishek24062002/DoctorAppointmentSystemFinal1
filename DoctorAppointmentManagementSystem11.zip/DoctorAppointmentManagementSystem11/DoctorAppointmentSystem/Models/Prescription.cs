﻿namespace DoctorAppointmentSystem.Models
{
    public class Prescription
    {

        public int PrescriptionId { get; set; }
        public Guid UserId { get; set; }
        public User User { get; set; }
        public int PatientProfileId { get; set; }
        public PatientProfile PatientProfile { get; set; }
        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }
        public int AppointmentId { get; set; }
        public Appointment Appointment { get; set; }    
        public string Notes { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
