﻿namespace DoctorAppointmentSystem.DTOs
{
    public class CreatePrescriptionDto
    {
        public int AppointmentId { get; set; }
        public int PatientProfileId { get; set; }
        public Guid UserId { get; set; }
        public string Notes { get; set; }
    }
}
