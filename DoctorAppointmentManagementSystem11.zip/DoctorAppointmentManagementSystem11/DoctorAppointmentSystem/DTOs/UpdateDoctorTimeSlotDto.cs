﻿namespace DoctorAppointmentSystem.DTOs
{
    public class UpdateDoctorTimeSlotDto
    {
        public int DoctorTimeSlotId { get; set; }
        public bool IsAvailable { get; set; }
    }
}
