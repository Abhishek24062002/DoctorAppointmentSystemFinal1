﻿namespace DoctorAppointmentSystem.DTOs
{
    public class FeedbackResponseDto
    {
        public int FeedbackId { get; set; }
        public string PatientName { get; set; }
        public string DoctorName { get; set; }
        public string Comment { get; set; }
        public int Rating { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
