﻿namespace DoctorAppointmentSystem.DTOs
{
    public class DoctorAvailabilityUpdateDto
    {
        public bool IsAvailable { get; set; }
    }

}
