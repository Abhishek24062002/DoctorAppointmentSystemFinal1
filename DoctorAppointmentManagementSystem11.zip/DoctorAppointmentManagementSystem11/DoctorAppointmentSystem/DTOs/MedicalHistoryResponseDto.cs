﻿namespace DoctorAppointmentSystem.DTOs
{
    public class MedicalHistoryResponseDto
    {
        public int MedicalHistoryId { get; set; }
        public string ConditionName { get; set; }
        public string Description { get; set; }
        public DateTime DiagnosedOn { get; set; }
        public string Treatment { get; set; }
    }
}
