﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointmentSystem.DTOs
{
    public class RescheduleAppointmentDto
    {
        [Required] public int AppointmentId { get; set; }
        [Required] public DateTime NewDate { get; set; }
        [Required] public string NewTimeSlot { get; set; }
    }

}
