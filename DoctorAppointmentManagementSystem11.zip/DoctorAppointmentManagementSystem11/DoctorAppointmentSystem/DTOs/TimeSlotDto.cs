﻿namespace DoctorAppointmentSystem.DTOs
{
    public class TimeSlotDto
    {
        public string Slot { get; set; }
        public bool IsAvailable { get; set; }
    }
}
