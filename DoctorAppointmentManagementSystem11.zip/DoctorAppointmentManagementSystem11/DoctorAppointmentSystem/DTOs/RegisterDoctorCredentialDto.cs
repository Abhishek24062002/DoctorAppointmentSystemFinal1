﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointmentSystem.DTOs
{
    public class RegisterDoctorCredentialDto
    {
        [Required]
        public int DoctorId { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        [Required]
        public int RoleId { get; set; } // This should be ID for "Doctor" in Roles table
    }

}
