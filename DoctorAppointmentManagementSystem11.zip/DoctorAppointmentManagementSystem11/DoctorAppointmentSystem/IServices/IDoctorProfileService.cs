﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public  interface IDoctorProfileService
    {
        Task<DoctorProfileResponseDto> GetOwnProfileAsync(int doctorId);
        Task UpdateOwnProfileAsync(int doctorId, DoctorProfileUpdateDto dto);

        Task<List<Appointment>> GetTodaysAppointmentsForDoctorAsync(int doctorId);
    }
}
