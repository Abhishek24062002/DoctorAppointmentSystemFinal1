﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IDoctorScheduleService
    {
        Task<DoctorWithSlotsDto> GetDoctorByIdWithSlotsAsync(int id);
        Task AddTimeSlotsAsync(int doctorId, List<CreateDoctorTimeSlotDto> slots);
        Task<List<DoctorTimeSlot>> GetOwnTimeSlotsAsync(int doctorId);
        Task<bool> UpdateTimeSlotAvailabilityAsync(int doctorId, UpdateDoctorTimeSlotDto dto);
        Task<bool> DeleteTimeSlotAsync(int doctorId, int slotId);
    }

}
