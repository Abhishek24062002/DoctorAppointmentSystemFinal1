﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IPrescriptionService
    {
        Task<int> CreatePrescriptionAsync(CreatePrescriptionDto dto, int doctorId);
        Task<List<Prescription>> GetPrescriptionsByPatientIdAsync(int patientProfileId);
        Task<List<Prescription>> GetPrescriptionsByAppointmentIdAsync(int appointmentId);
        Task<List<Prescription>> GetAllPrescriptionsForDoctorAsync(int doctorId);
    }

}
