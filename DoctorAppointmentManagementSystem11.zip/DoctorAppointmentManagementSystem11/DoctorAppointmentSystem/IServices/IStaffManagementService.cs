﻿using DoctorAppointmentSystem.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IStaffManagementService
    {
        Task<int> RegisterStaffAsync(StaffRegisterDto dto);
        Task<bool> AssignDoctorToStaffAsync(int staffId, int doctorId);
        Task<bool> UpdateStaffAsync(StaffUpdateDto dto);
        Task<bool> DeleteStaffAsync(int staffId);
    }

}
