﻿namespace DoctorAppointmentSystem.IServices
{
    public interface IPaymentService
    {
        Task<bool> ProcessPaymentAsync(int appointmentId, decimal amount);
    }

}
