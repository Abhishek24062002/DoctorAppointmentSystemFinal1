﻿using DoctorAppointmentSystem.DTOs;

namespace DoctorAppointmentSystem.IServices

{
    public interface IPasswordResetService
    {
        Task<string> RequestPasswordResetAsync(string email, string origin);
        Task ResetPasswordAsync(ResetPasswordRequest model);
    }


}
