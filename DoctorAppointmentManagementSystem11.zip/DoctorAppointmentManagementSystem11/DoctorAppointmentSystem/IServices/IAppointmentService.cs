﻿
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.DTOs.DTOs;
using DoctorAppointmentSystem.Models;

namespace DoctorAppointmentSystem.IServices
{
    public interface IAppointmentService
    {
        Task<int> BookAppointmentAsync(CreateAppointmentDto dto);
        Task<List<Appointment>> GetAppointmentsByPatientId(int patientId);
        Task<bool> RescheduleAsync(RescheduleAppointmentDto dto);
        Task<bool> CancelAsync(int appointmentId);
        Task<bool> MarkAsPaidAsync(int appointmentId);
        Task<List<Appointment>> GetAllAppointmentsAsync();
        Task<PatientProfile> GetPatientProfileByUserIdAsync(string userId);



    }

}
