﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IPatientService
    {
        Task<int> CreatePatientProfileAsync(PatientProfileDto dto, IFormFile medicalHistoryPdf, Guid UserId);
        Task<List<PatientProfile>> GetAllProfilesAsync();
        Task<PatientProfile> GetProfileByIdAsync(int id);
    }

}
