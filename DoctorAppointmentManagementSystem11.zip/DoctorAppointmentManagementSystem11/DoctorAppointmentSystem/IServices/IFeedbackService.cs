﻿using DoctorAppointmentSystem.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IFeedbackService
    {
        Task<bool> SubmitFeedbackAsync(FeedbackDto dto);
        Task<List<FeedbackResponseDto>> GetFeedbacksByDoctorIdAsync(int doctorId);
        Task<List<FeedbackResponseDto>> GetFeedbacksByPatientProfileIdAsync(int patientProfileId);
        Task<List<FeedbackResponseDto>> GetAllFeedbacksAsync(); // For Admin/Staff
    }
}
