﻿using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminPaymentController : ControllerBase
    {
        private readonly IAdminPaymentService _adminService;

        public AdminPaymentController(IAdminPaymentService adminService) => _adminService = adminService;

        [HttpGet("payments")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllPayments()
        {
            var payments = await _adminService.GetAllPaymentsAsync();
            return Ok(payments);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("payments/search")]
        public async Task<IActionResult> SearchPayments(
            [FromQuery] string? email,
            [FromQuery] DateTime? startDate,
            [FromQuery] DateTime? endDate)
        {
            var payments = await _adminService.SearchPaymentsAsync(email, startDate, endDate);
            return Ok(payments);
        }
    }
}
