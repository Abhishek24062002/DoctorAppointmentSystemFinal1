﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffAppointmentController : ControllerBase
    {
        public readonly IStaffAppointmentService _svc;

        public StaffAppointmentController(IStaffAppointmentService service) => _svc = service;

        [Authorize(Roles = "Staff")]
        [HttpGet("appointments/today")]
        public async Task<IActionResult> GetTodaysAppointments()
        {
            var staffIdStr = User.FindFirst("StaffId")?.Value;
            if (!int.TryParse(staffIdStr, out var staffId))
                return Unauthorized();

            var list = await _svc.GetTodaysAppointmentsForStaffAsync(staffId);
            return Ok(list);
        }

        [Authorize(Roles = "Staff")]
        [HttpPost("appointments/reschedule")]
        public async Task<IActionResult> Reschedule(int appointmentId, DateTime newDate, string newTimeSlot)
        {
            return await _svc.RescheduleAppointmentAsync(appointmentId, newDate, newTimeSlot)
                ? Ok("Rescheduled")
                : NotFound();
        }

        [Authorize(Roles = "Staff")]
        [HttpPost("appointments/complete/{id}")]
        public async Task<IActionResult> Complete(int id)
        {
            return await _svc.MarkAppointmentCompletedAsync(id)
                ? Ok("Completed")
                : NotFound();
        }

        [Authorize(Roles = "Staff")]
        [HttpPut("doctor/{doctorId}/availability")]
        public async Task<IActionResult> UpdateDoctorAvailability(int doctorId, [FromBody] DoctorAvailabilityUpdateDto dto)
        {
            var success = await _svc.UpdateDoctorAvailabilityAsync(doctorId, dto.IsAvailable);
            if (!success) return NotFound("Doctor not found.");

            return Ok(new { message = "Doctor availability updated successfully." });
        }
    }

}