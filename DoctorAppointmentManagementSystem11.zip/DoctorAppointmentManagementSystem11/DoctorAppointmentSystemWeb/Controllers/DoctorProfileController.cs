﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorProfileController : ControllerBase
    {

        private readonly IDoctorProfileService _service;

        public DoctorProfileController(IDoctorProfileService service)
        {
            _service = service;
        }


        [Authorize(Roles = "Doctor")]
        [HttpGet("profile")]
        public async Task<IActionResult> GetOwnProfile()
        {
            var doctorIdClaim = User.FindFirst("doctorId")?.Value;
            if (!int.TryParse(doctorIdClaim, out int doctorId))
                return Unauthorized("Invalid Doctor ID");

            var profile = await _service.GetOwnProfileAsync(doctorId);
            return Ok(profile);
        }


        [Authorize(Roles = "Doctor")]
        [HttpPut("profile")]
        public async Task<IActionResult> UpdateOwnProfile([FromBody] DoctorProfileUpdateDto dto)
        {
            var doctorIdClaim = User.FindFirst("doctorId")?.Value;
            if (!int.TryParse(doctorIdClaim, out int doctorId))
                return Unauthorized("Invalid Doctor ID");

            await _service.UpdateOwnProfileAsync(doctorId, dto);
            return Ok("Profile updated successfully.");
        }


         // ✅ DOCTOR INTERFACE: Get today's appointments (max 12) with patient details
        [Authorize(Roles = "Doctor")]
        [HttpGet("appointments/today")]
        public async Task<IActionResult> GetTodaysAppointments()
        {
            // ✅ Fetch from custom "DoctorId" claim
            var doctorIdStr = User.FindFirst("DoctorId")?.Value;

            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid doctor ID in token.");

            var appointments = await _service.GetTodaysAppointmentsForDoctorAsync(doctorId);

         

            var grouped = appointments
                .GroupBy(a => a.TimeSlot)
                .Select(g => new
                {
                    TimeSlot = g.Key,
                    Appointments = g
                    .OrderBy(a => a.Date)
                    .Take(5)
                    .Select(a => new
                    {
                        a.AppointmentId,
                        a.Date,
                        a.Status,
                        Patient = new
                        {
                            a.PatientProfile.PatientProfileId,
                            a.PatientProfile.Name,
                            a.PatientProfile.Age,
                            a.PatientProfile.Gender,
                            a.PatientProfile.Address,
                            a.PatientProfile.Mobile,
                            a.PatientProfile.BloodGroup,
                            a.PatientProfile.MedicalHistoryPath
                        }

                    }).ToList()
                }).ToList();

            return Ok(new
            {
                date=DateTime.Today.ToString("yyyy-MM-dd"),
                totalSlots=grouped.Count,
                groupedAppointments=grouped
            });
        }


    }
}
