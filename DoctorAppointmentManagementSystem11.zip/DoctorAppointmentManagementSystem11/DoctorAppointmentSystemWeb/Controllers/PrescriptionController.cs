﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrescriptionController : ControllerBase
    {
        private readonly IPrescriptionService _service;

        public PrescriptionController(IPrescriptionService service)
        {
            _service = service;
        }

        [Authorize(Roles = "Doctor")]
        [HttpPost("prescription")]
        public async Task<IActionResult> CreatePrescription([FromBody] CreatePrescriptionDto dto)
        {
            var doctorIdStr = User.FindFirst("DoctorId")?.Value;
            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid Doctor ID");

            var id = await _service.CreatePrescriptionAsync(dto, doctorId);
            return Ok(new { prescriptionId = id });
        }

        [Authorize(Roles = "Doctor,Patient,Staff")]
        [HttpGet("prescription/patient/{patientProfileId}")]
        public async Task<IActionResult> GetPrescriptionsByPatient(int patientProfileId)
        {
            var prescriptions = await _service.GetPrescriptionsByPatientIdAsync(patientProfileId);
            return Ok(prescriptions);
        }

        [Authorize(Roles = "Doctor,Patient,Staff")]
        [HttpGet("prescription/appointment/{appointmentId}")]
        public async Task<IActionResult> GetPrescriptionsByAppointment(int appointmentId)
        {
            var prescriptions = await _service.GetPrescriptionsByAppointmentIdAsync(appointmentId);
            return Ok(prescriptions);
        }

        [Authorize(Roles = "Doctor")]
        [HttpGet("prescriptions/my")]
        public async Task<IActionResult> GetPrescriptionsByDoctor()
        {
            var doctorIdStr = User.FindFirst("DoctorId")?.Value;
            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid Doctor ID");

            var prescriptions = await _service.GetAllPrescriptionsForDoctorAsync(doctorId);
            return Ok(prescriptions);
        }
    }
}
