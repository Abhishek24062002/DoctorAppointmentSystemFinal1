﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackController : ControllerBase
    {
        private readonly IFeedbackService _service;

        public FeedbackController(IFeedbackService service)
        {
            _service = service;
        }

        // ✅ Patient submits feedback
        [Authorize(Roles = "Patient")]
        [HttpPost]
        public async Task<IActionResult> SubmitFeedback(FeedbackDto dto)
        {
            var result = await _service.SubmitFeedbackAsync(dto);
            return result ? Ok("Feedback submitted.") : BadRequest("Submission failed.");
        }

        // ✅ Doctor gets their feedback
        [Authorize(Roles = "Doctor")]
        [HttpGet("doctor")]
        public async Task<IActionResult> GetDoctorFeedback()
        {
            var doctorIdStr = User.FindFirst("doctorId")?.Value;
            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid Doctor ID");

            var feedbacks = await _service.GetFeedbacksByDoctorIdAsync(doctorId);
            return Ok(feedbacks);
        }

        // ✅ Patient views own feedback
        [Authorize(Roles = "Patient")]
        [HttpGet("patient/{patientProfileId}")]
        public async Task<IActionResult> GetFeedbackByPatient(int patientProfileId)
        {
            var feedbacks = await _service.GetFeedbacksByPatientProfileIdAsync(patientProfileId);
            return Ok(feedbacks);
        }

        // ✅ Admin and Staff can view all feedback
        [Authorize(Roles = "Admin,Staff")]
        [HttpGet("all")]
        public async Task<IActionResult> GetAllFeedbacks()
        {
            var feedbacks = await _service.GetAllFeedbacksAsync();
            return Ok(feedbacks);
        }
    }

}
