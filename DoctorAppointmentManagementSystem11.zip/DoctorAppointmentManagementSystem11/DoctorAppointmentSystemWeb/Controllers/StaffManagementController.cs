﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffManagementController : ControllerBase
    {
        public readonly IStaffManagementService _svc;
        public StaffManagementController(IStaffManagementService svc)
        {
            _svc = svc;
        }


        [Authorize(Roles = "Admin")]
        [HttpPost("register")]
        public async Task<IActionResult> Register(StaffRegisterDto dto)
        {
            var id = await _svc.RegisterStaffAsync(dto);
            return Ok(new { staffId = id, message = "Staff created with login." });
        }


        [Authorize(Roles = "Admin")]
        [HttpPost("assign-doctor")]
        public async Task<IActionResult> AssignDoctorToStaff([FromBody] AssignDoctorDto dto)
        {
            var success = await _svc.AssignDoctorToStaffAsync(dto.StaffId, dto.DoctorId);
            if (!success) return BadRequest("Doctor is already assigned or invalid IDs.");

            return Ok(new
            {
                message = "Doctor assigned to staff successfully.",
                dto.StaffId,
                dto.DoctorId
            });
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("update")]
        public async Task<IActionResult> Update(StaffUpdateDto dto)
        {
            return await _svc.UpdateStaffAsync(dto)
                ? Ok("Staff updated.")
                : NotFound();
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return await _svc.DeleteStaffAsync(id)
                ? Ok("Staff deleted.")
                : NotFound();
        }
    }
}
