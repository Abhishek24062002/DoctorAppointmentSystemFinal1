﻿using DoctorAppointmentSystem.DTOs;
using Microsoft.AspNetCore.Mvc;
using DoctorAppointmentSystem.IServices;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _auth;
        private readonly IPasswordResetService _passwordReset;

        public AuthController(IAuthService auth, IPasswordResetService passwordReset)
        {
            _auth = auth;
            _passwordReset = passwordReset;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest dto)
        {
            await _auth.RegisterAsync(dto);
            return Ok(new { message = "Registration successful" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest dto)
        {
            var token = await _auth.LoginAsync(dto);
            return Ok(new { token });
        }


        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordRequest dto)
        {
            var token = await _passwordReset.RequestPasswordResetAsync(dto.Email, Request.Headers["origin"]);

            return Ok(new { message = "If that email is registered, you will receive a reset link shortly.",
            token});
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword(ResetPasswordRequest dto)
        {
            await _passwordReset.ResetPasswordAsync(dto);
            return Ok(new { message = "Password has been reset successfully." });
        }

    }
}
