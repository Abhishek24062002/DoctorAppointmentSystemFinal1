﻿using DoctorAppointmentSystem.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IDoctorRegistrationService
    {
        Task<int> RegisterDoctorAsync(DoctorRegisterDto dto);
        Task<bool> UpdateDoctorAsync(int id, DoctorUpdateDto dto);
        Task<bool> DeleteDoctorAsync(int id);
        Task<bool> RegisterDoctorCredentialAsync(RegisterDoctorCredentialDto dto);
    }

}
