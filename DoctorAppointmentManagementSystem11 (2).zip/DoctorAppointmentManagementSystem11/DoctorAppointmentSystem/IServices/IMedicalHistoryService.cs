﻿using DoctorAppointmentSystem.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IMedicalHistoryService
    {
        Task AddMedicalHistoryAsync(int patientProfileId, MedicalHistoryDto dto);
        Task<List<MedicalHistoryResponseDto>> GetMedicalHistoryAsync(int patientProfileId);
    }

}
