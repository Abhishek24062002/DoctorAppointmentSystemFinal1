﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IStaffAppointmentService
    {
        Task<List<Appointment>> GetTodaysAppointmentsForStaffAsync(int staffId);
        Task<bool> RescheduleAppointmentAsync(int appointmentId, DateTime newDate, string newSlot);
        Task<bool> MarkAppointmentCompletedAsync(int appointmentId);
        Task<bool> UpdateDoctorAvailabilityAsync(int doctorId, bool isAvailable);
    }

}
