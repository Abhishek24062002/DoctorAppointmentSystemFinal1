﻿using DoctorAppointmentSystem.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IAdminPaymentService
    {
        Task<List<PaymentDto>> GetAllPaymentsAsync();
        Task<List<PaymentDto>> SearchPaymentsAsync(string? email, DateTime? startDate, DateTime? endDate);
    }

}
