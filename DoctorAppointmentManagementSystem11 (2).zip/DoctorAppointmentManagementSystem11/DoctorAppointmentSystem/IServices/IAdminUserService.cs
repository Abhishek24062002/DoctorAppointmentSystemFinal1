﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.IServices
{
    public interface IAdminUserService
    {
        Task<List<User>> GetAllUsersAsync();
        Task<User> GetUserByIdAsync(Guid userId);
        Task<bool> UpdateUserAsync(Guid userId, UserUpdateDto dto);
        Task<bool> DeleteUserAsync(Guid userId);
        Task<List<User>> SearchUsersAsync(string? email, string? role);
    }

}
