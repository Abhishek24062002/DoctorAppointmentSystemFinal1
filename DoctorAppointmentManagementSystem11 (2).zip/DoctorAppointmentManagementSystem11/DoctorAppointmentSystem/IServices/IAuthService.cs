﻿using DoctorAppointmentSystem.DTOs;

namespace DoctorAppointmentSystem.IServices

{
    public interface IAuthService
    {
        Task RegisterAsync(RegisterRequest model);
        Task<string> LoginAsync(LoginRequest model);
    }

}
