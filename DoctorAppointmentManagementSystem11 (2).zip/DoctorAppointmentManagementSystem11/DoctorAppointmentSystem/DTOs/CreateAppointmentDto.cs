﻿using System.ComponentModel.DataAnnotations;

namespace  DoctorAppointmentSystem.DTOs
.DTOs
{
    public class CreateAppointmentDto
    {
        [Required] public int PatientProfileId { get; set; }
        [Required] public int DoctorId { get; set; }
        [Required] public DateTime Date { get; set; }
        [Required] public string TimeSlot { get; set; }
        [Required] public decimal Fee { get; set; }
    }

}
