﻿namespace DoctorAppointmentSystem.DTOs
{
    public class MedicalHistoryDto
    {
        public string ConditionName { get; set; }
        public string Description { get; set; }
        public DateTime DiagnosedOn { get; set; }
        public string Treatment { get; set; }
    }
}
