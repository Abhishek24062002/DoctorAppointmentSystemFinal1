﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointmentSystem.DTOs
{
    public class StaffUpdateDto
    {
        [Required] public int StaffId { get; set; }
        public string Name { get; set; }
        public int? Age { get; set; }
        public string Gender { get; set; }
        public string Mobile { get; set; }
        public string Location { get; set; }
    }

}
