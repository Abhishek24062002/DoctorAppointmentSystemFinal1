﻿namespace DoctorAppointmentSystem.DTOs
{
    public class FeedbackDto
    {
        public int PatientProfileId { get; set; }
        public int DoctorId { get; set; }
        public string Comment { get; set; }
        public int Rating { get; set; } // optional
    }
}
