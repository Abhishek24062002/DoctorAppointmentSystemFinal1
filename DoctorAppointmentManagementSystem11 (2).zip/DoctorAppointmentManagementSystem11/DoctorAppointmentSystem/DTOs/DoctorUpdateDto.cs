﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointmentSystem.DTOs
{
    public class DoctorUpdateDto
    {
        [Required] public string Name { get; set; }
        [Required] public string Gender { get; set; }
        [Required] public int Age { get; set; }
        [Required] public string Location { get; set; }
        [Required] public string Speciality { get; set; }
        public string Education { get; set; }
        public int ExperienceYears { get; set; }
    }

}
