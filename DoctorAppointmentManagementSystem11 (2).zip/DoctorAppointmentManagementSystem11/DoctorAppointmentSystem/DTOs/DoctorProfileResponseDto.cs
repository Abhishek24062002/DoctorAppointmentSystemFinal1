﻿namespace DoctorAppointmentSystem.DTOs
{
    public class DoctorProfileResponseDto
    {
        public int DoctorId { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string Location { get; set; }
        public string Speciality { get; set; }
        public string Education { get; set; }
        public int ExperienceYears { get; set; }
    }
}
