﻿namespace DoctorAppointmentSystem.DTOs
{
    public class AssignDoctorDto
    {
        public int StaffId { get; set; }
        public int DoctorId { get; set; }
    }

}
