﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointmentSystem.DTOs
{
    public class ResetPasswordRequest
    {
        [Required] public string Token { get; set; }
        [Required, MinLength(6)] public string NewPassword { get; set; }
    }

}
