﻿namespace DoctorAppointmentSystem.DTOs
{
    public class CreateDoctorTimeSlotDto
    {
        public string TimeSlot { get; set; } // e.g., "09:00 AM - 09:30 AM"
        public bool IsAvailable { get; set; } = true;
    }
}
