﻿namespace DoctorAppointmentSystem.DTOs
{
    public class DoctorWithSlotsDto
    {
        public int DoctorId { get; set; }
        public string Name { get; set; }
        public string Speciality { get; set; }
        public bool IsAvailable { get; set; }
        public List<TimeSlotDto> TimeSlots { get; set; }
    }
}
