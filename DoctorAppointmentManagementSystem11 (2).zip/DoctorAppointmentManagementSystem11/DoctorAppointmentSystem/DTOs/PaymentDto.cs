﻿namespace DoctorAppointmentSystem.DTOs
{
    public class PaymentDto
    {
        public Guid UserId { get; set; }
        public string UserFullName { get; set; }
        public string UserEmail { get; set; }
        public int PatientProfileId { get; set; }
        public string PatientName { get; set; }
        public int AppointmentId { get; set; }
        public DateTime AppointmentDate { get; set; }
        public string TimeSlot { get; set; }
        public decimal Amount { get; set; }
        public bool IsPaid { get; set; }
    }
}
