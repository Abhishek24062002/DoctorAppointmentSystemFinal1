﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointmentSystem.DTOs
{
    public class PatientProfileDto
    {
        [Required] public string Name { get; set; }
        [Required] public int Age { get; set; }
        [Required] public string Gender { get; set; }
        [Required] public string Address { get; set; }
        [Required] public string Mobile { get; set; }
        [Required] public string BloodGroup { get; set; }
    }

}
