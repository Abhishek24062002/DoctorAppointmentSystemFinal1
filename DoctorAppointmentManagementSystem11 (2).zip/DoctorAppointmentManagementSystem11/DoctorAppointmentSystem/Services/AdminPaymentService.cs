﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.EntityFrameworkCore;

namespace DoctorAppointmentSystem.Services
{
    public class AdminPaymentService : IAdminPaymentService
    {
        public readonly AppDbContext _ctx;

        public AdminPaymentService(AppDbContext appDbContext) => _ctx = appDbContext;


        public async Task<List<PaymentDto>> GetAllPaymentsAsync()
        {
            var payments = await _ctx.Appointments
                .Include(a => a.PatientProfile)
                    .ThenInclude(p => p.User)
                .Where(a => a.IsPaid == true)
                .Select(a => new PaymentDto
                {
                    UserId = a.PatientProfile.User.UserId,
                    UserFullName = a.PatientProfile.User.FullName,
                    UserEmail = a.PatientProfile.User.Email,

                    PatientProfileId = a.PatientProfileId,
                    PatientName = a.PatientProfile.Name,

                    AppointmentId = a.AppointmentId,
                    AppointmentDate = a.Date,
                    TimeSlot = a.TimeSlot,

                    Amount = a.Fee,
                    IsPaid = a.IsPaid
                })
                .ToListAsync();

            return payments;
        }


        public async Task<List<PaymentDto>> SearchPaymentsAsync(string? email, DateTime? startDate, DateTime? endDate)
        {
            var query = _ctx.Appointments
                .Include(a => a.PatientProfile)
                    .ThenInclude(p => p.User)
                .Where(a => a.IsPaid == true)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(email))
            {
                query = query.Where(a => a.PatientProfile.User.Email.Contains(email));
            }

            if (startDate.HasValue)
            {
                query = query.Where(a => a.Date >= startDate.Value.Date);
            }

            if (endDate.HasValue)
            {
                query = query.Where(a => a.Date <= endDate.Value.Date);
            }

            return await query.Select(a => new PaymentDto
            {
                UserId = a.PatientProfile.User.UserId,
                UserFullName = a.PatientProfile.User.FullName,
                UserEmail = a.PatientProfile.User.Email,

                PatientProfileId = a.PatientProfileId,
                PatientName = a.PatientProfile.Name,

                AppointmentId = a.AppointmentId,
                AppointmentDate = a.Date,
                TimeSlot = a.TimeSlot,

                Amount = a.Fee,
                IsPaid = a.IsPaid
            }).ToListAsync();
        }




    }

}


/*
 1. 🗂️ _ctx.Appointments
Starts by querying the Appointments table in your database using Entity Framework Core.

2. 📎 .Include(a => a.PatientProfile)
Tells EF Core to eagerly load related data from the PatientProfile navigation property.

This prevents the need for separate database calls later (lazy loading).

3. 🔗 .ThenInclude(p => p.User)
Drills down further into the User entity associated with each PatientProfile.

So you're loading: → Appointment → PatientProfile → User (of that patient)

4. ✅ .Where(a => a.IsPaid == true)
Filters the appointments: Only selects those where IsPaid is true.

5. 🔄 .AsQueryable()
Converts the result into an IQueryable, allowing for further query composition if needed later.

Also enables deferred execution—this query doesn't hit the database until it's enumerated (e.g., with .ToListAsync()).
 */