﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DoctorAppointmentSystem.Services
{
    public class DoctorProfileService : IDoctorProfileService

    {
        private readonly AppDbContext _ctx;

        public DoctorProfileService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<DoctorProfileResponseDto> GetOwnProfileAsync(int doctorId)
        {
            var doctor = await _ctx.Doctors.FindAsync(doctorId);
            if (doctor == null) throw new Exception("Doctor not found");

            return new DoctorProfileResponseDto
            {
                DoctorId = doctor.DoctorId,
                Name = doctor.Name,
                Gender = doctor.Gender,
                Age = doctor.Age,
                Location = doctor.Location,
                Speciality = doctor.Speciality,
                Education = doctor.Education,
                ExperienceYears = doctor.ExperienceYears
            };
        }

        public async Task UpdateOwnProfileAsync(int doctorId, DoctorProfileUpdateDto dto)
        {
            var doctor = await _ctx.Doctors.FindAsync(doctorId);
            if (doctor == null) throw new Exception("Doctor not found");

            doctor.Name = dto.Name;
            doctor.Gender = dto.Gender;
            doctor.Age = dto.Age;
            doctor.Location = dto.Location;
            doctor.Speciality = dto.Speciality;
            doctor.Education = dto.Education;
            doctor.ExperienceYears = dto.ExperienceYears;

            await _ctx.SaveChangesAsync();
        }

        public async Task<List<Appointment>> GetTodaysAppointmentsForDoctorAsync(int doctorId)
        {
            return await _ctx.Appointments
                .Include(a => a.PatientProfile)
                .Where(a =>
                    a.DoctorId == doctorId &&
                    a.Date.Date == DateTime.Today &&
                    (a.Status == "Booked" || a.Status == "Confirmed")
                )
                .ToListAsync();


        }
    }
}
