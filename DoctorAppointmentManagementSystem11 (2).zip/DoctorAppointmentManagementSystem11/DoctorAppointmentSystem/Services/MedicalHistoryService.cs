﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Services
{
    public class MedicalHistoryService : IMedicalHistoryService
    {
        private readonly AppDbContext _ctx;

        public MedicalHistoryService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task AddMedicalHistoryAsync(int patientProfileId, MedicalHistoryDto dto)
        {
            var exists = await _ctx.PatientProfiles.AnyAsync(p => p.PatientProfileId == patientProfileId);
            if (!exists) throw new Exception("Invalid Patient ID");

            var history = new MedicalHistory
            {
                PatientProfileId = patientProfileId,
                ConditionName = dto.ConditionName,
                Description = dto.Description,
                DiagnosedOn = dto.DiagnosedOn,
                Treatment = dto.Treatment
            };

            _ctx.MedicalHistories.Add(history);
            await _ctx.SaveChangesAsync();
        }

        public async Task<List<MedicalHistoryResponseDto>> GetMedicalHistoryAsync(int patientProfileId)
        {
            return await _ctx.MedicalHistories
                .Where(m => m.PatientProfileId == patientProfileId)
                .Select(m => new MedicalHistoryResponseDto
                {
                    MedicalHistoryId = m.MedicalHistoryId,
                    ConditionName = m.ConditionName,
                    Description = m.Description,
                    DiagnosedOn = m.DiagnosedOn,
                    Treatment = m.Treatment
                }).ToListAsync();
        }
    }

}
