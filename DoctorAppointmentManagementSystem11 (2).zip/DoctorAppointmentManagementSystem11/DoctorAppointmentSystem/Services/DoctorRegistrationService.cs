﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointmentSystem.Repository
{
    public class DoctorRegistrationService : IDoctorRegistrationService
    {
        private readonly AppDbContext _ctx;

        public DoctorRegistrationService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<int> RegisterDoctorAsync(DoctorRegisterDto dto)
        {
            var doctor = new Doctor
            {
                Name = dto.Name,
                Gender = dto.Gender,
                Age = dto.Age,
                Location = dto.Location,
                Speciality = dto.Speciality,
                Education = dto.Education,
                ExperienceYears = dto.ExperienceYears
            };

            _ctx.Doctors.Add(doctor);
            await _ctx.SaveChangesAsync();
            return doctor.DoctorId;
        }

        public async Task<bool> RegisterDoctorCredentialAsync(RegisterDoctorCredentialDto dto)
        {
            // Step 1: Check doctor exists
            var doctor = await _ctx.Doctors.FindAsync(dto.DoctorId);
            if (doctor == null) return false;

            // Step 2: Check if already mapped
            bool alreadyExists = await _ctx.DoctorCredentials.AnyAsync(dc => dc.DoctorId == dto.DoctorId);
            if (alreadyExists) return false;

            // Step 3: Create DoctorCredential
            var docCred = new DoctorCredential
            {
                DoctorId = dto.DoctorId,
                Email = dto.Email
            };
            _ctx.DoctorCredentials.Add(docCred);

            // Step 4: Create User (login)
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password);

            var user = new User
            {
                UserId = Guid.NewGuid(),
                FullName = doctor.Name,
                Email = dto.Email,
                Age = doctor.Age,
                Gender = doctor.Gender,
                PasswordHash = passwordHash,
                RoleId = dto.RoleId, // e.g., 2 => Doctor
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            _ctx.Users.Add(user);

            await _ctx.SaveChangesAsync();
            return true;
        }


        public async Task<bool> UpdateDoctorAsync(int id, DoctorUpdateDto dto)
        {
            var doctor = await _ctx.Doctors.FindAsync(id);
            if (doctor == null) return false;

            doctor.Name = dto.Name;
            doctor.Gender = dto.Gender;
            doctor.Age = dto.Age;
            doctor.Location = dto.Location;
            doctor.Speciality = dto.Speciality;
            doctor.Education = dto.Education;
            doctor.ExperienceYears = dto.ExperienceYears;

            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteDoctorAsync(int id)
        {
            var doctor = await _ctx.Doctors.FindAsync(id);
            if (doctor == null) return false;

            _ctx.Doctors.Remove(doctor);
            await _ctx.SaveChangesAsync();
            return true;
        }
    }
}
