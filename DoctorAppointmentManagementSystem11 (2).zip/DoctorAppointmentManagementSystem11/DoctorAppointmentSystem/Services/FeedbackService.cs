﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DoctorAppointmentSystem.Services
{
    public class FeedbackService : IFeedbackService
    {
        private readonly AppDbContext _ctx;

        public FeedbackService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<bool> SubmitFeedbackAsync(FeedbackDto dto)
        {
            var feedback = new Feedback
            {
                PatientProfileId = dto.PatientProfileId,
                DoctorId = dto.DoctorId,
                Comment = dto.Comment,
                Rating = dto.Rating
            };

            _ctx.Feedbacks.Add(feedback);
            await _ctx.SaveChangesAsync();
            return true;
        }

        public async Task<List<FeedbackResponseDto>> GetFeedbacksByDoctorIdAsync(int doctorId)
        {
            return await _ctx.Feedbacks
                .Where(f => f.DoctorId == doctorId)
                .Include(f => f.Doctor)
                .Include(f => f.PatientProfile)
                .Select(f => new FeedbackResponseDto
                {
                    FeedbackId = f.FeedbackId,
                    PatientName = f.PatientProfile.Name,
                    DoctorName = f.Doctor.Name,
                    Comment = f.Comment,
                    Rating = f.Rating,
                    CreatedAt = f.CreatedAt
                }).ToListAsync();
        }

        public async Task<List<FeedbackResponseDto>> GetFeedbacksByPatientProfileIdAsync(int patientProfileId)
        {
            return await _ctx.Feedbacks
                .Where(f => f.PatientProfileId == patientProfileId)
                .Include(f => f.Doctor)
                .Include(f => f.PatientProfile)
                .Select(f => new FeedbackResponseDto
                {
                    FeedbackId = f.FeedbackId,
                    PatientName = f.PatientProfile.Name,
                    DoctorName = f.Doctor.Name,
                    Comment = f.Comment,
                    Rating = f.Rating,
                    CreatedAt = f.CreatedAt
                }).ToListAsync();
        }

        public async Task<List<FeedbackResponseDto>> GetAllFeedbacksAsync()
        {
            return await _ctx.Feedbacks
                .Include(f => f.Doctor)
                .Include(f => f.PatientProfile)
                .Select(f => new FeedbackResponseDto
                {
                    FeedbackId = f.FeedbackId,
                    PatientName = f.PatientProfile.Name,
                    DoctorName = f.Doctor.Name,
                    Comment = f.Comment,
                    Rating = f.Rating,
                    CreatedAt = f.CreatedAt
                }).ToListAsync();
        }
    }

}
