﻿using DoctorAppointmentSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DoctorAppointmentSystem.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserPasswordReset> UserPasswordResets { get; set; }
        public DbSet<PatientProfile> PatientProfiles { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<DoctorCredential> DoctorCredentials { get; set; }
        public DbSet<Staff> Staffs { get; set; }
        public DbSet<StaffCredential> StaffCredentials { get; set; }
        public DbSet<StaffDoctorMap> StaffDoctorMaps { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<MedicalHistory> MedicalHistories { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<DoctorTimeSlot> DoctorTimeSlots { get; set; }

        public DbSet<Prescription> Prescriptions { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Role>().HasData(
                new Role { RoleId = 1, Name = "Patient" },
                new Role { RoleId = 2, Name = "Doctor" },
                new Role { RoleId = 3, Name = "Admin" },
                new Role { RoleId = 4, Name = "Staff" }
            );

            modelBuilder.Entity<StaffDoctorMap>()
                .HasKey(sd => new { sd.StaffId, sd.DoctorId });

            modelBuilder.Entity<StaffDoctorMap>()
                .HasOne(sd => sd.Staff)
                .WithMany()
                .HasForeignKey(sd => sd.StaffId);

            modelBuilder.Entity<StaffDoctorMap>()
                .HasOne(sd => sd.Doctor)
                .WithMany()
                .HasForeignKey(sd => sd.DoctorId);

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<PatientProfile>()
                .HasOne(p => p.User)
                .WithMany()
                .HasForeignKey(p => p.UserId)
                .IsRequired();

            // Payment ↔ PatientProfile
            modelBuilder.Entity<Payment>()
                .HasOne(p => p.PatientProfile)
                .WithMany()
                .HasForeignKey(p => p.PatientProfileId)
                .OnDelete(DeleteBehavior.Restrict);

            // Payment ↔ Appointment
            modelBuilder.Entity<Payment>()
                .HasOne(p => p.Appointment)
                .WithMany()
                .HasForeignKey(p => p.AppointmentId)
                .OnDelete(DeleteBehavior.Restrict);

            // Payment ↔ User
            modelBuilder.Entity<Payment>()
                .HasOne(p => p.User)
                .WithMany()
                .HasForeignKey(p => p.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<DoctorTimeSlot>()
                .HasOne(d => d.Doctor)
                .WithMany(t => t.TimeSlots)
                .HasForeignKey(d => d.DoctorId);


            modelBuilder.Entity<Prescription>()
                .HasOne(p => p.User)
                .WithMany()
                .HasForeignKey(p => p.UserId)
                .OnDelete(DeleteBehavior.Restrict); // ❌ Disable cascade

            modelBuilder.Entity<Prescription>()
                .HasOne(p => p.Doctor)
                .WithMany()
                .HasForeignKey(p => p.DoctorId)
                .OnDelete(DeleteBehavior.Restrict); // ❌ Disable cascade

            modelBuilder.Entity<Prescription>()
                .HasOne(p => p.PatientProfile)
                .WithMany()
                .HasForeignKey(p => p.PatientProfileId)
                .OnDelete(DeleteBehavior.Restrict); // ❌ Disable cascade

            modelBuilder.Entity<Prescription>()
                .HasOne(p => p.Appointment)
                .WithMany()
                .HasForeignKey(p => p.AppointmentId)
                .OnDelete(DeleteBehavior.Restrict); // ❌ Disable cascade
        }
    }
}

//It tells EF Core to restrict deletion of a Doctor if any Prescription is still referencing them.