﻿namespace DoctorAppointmentSystem.Models
{
    public class StaffDoctorMap
    {
        public int StaffId { get; set; }
        public Staff Staff { get; set; }

        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }
    }

}
