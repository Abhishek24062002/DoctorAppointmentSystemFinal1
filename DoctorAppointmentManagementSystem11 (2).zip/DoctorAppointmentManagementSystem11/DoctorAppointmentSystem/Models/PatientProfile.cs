﻿namespace DoctorAppointmentSystem.Models
{
    public class PatientProfile
    {
        public Guid UserId { get; set; } // ⬅️ Link to logged-in user
        public User User { get; set; }
        public int PatientProfileId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string Mobile { get; set; }
        public string BloodGroup { get; set; }
        public string MedicalHistoryPath { get; set; }
    }
}
