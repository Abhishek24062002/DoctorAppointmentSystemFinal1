﻿using System.Text.Json.Serialization;

namespace DoctorAppointmentSystem.Models
{
    public class DoctorTimeSlot
    {
        public int DoctorTimeSlotId { get; set; }
        public int DoctorId { get; set; }

        [JsonIgnore]
        public Doctor Doctor { get; set; }

        public string TimeSlot { get; set; } // e.g., "09:00 AM - 09:30 AM"
        public bool IsAvailable { get; set; } = true;
    }
}
