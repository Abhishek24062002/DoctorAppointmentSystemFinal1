﻿namespace DoctorAppointmentSystem.Models
{
    public class Feedback
    {
        public int FeedbackId { get; set; }

        // FK to PatientProfile
        public int PatientProfileId { get; set; }
        public PatientProfile PatientProfile { get; set; }

        // FK to Doctor
        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }

        public string Comment { get; set; }
        public int Rating { get; set; } // (Optional: 1 to 5 scale)

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
