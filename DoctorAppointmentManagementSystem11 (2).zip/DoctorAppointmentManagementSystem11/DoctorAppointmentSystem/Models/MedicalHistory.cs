﻿namespace DoctorAppointmentSystem.Models
{
    public class MedicalHistory
    {
        public int MedicalHistoryId { get; set; }

        public int PatientProfileId { get; set; }
        public PatientProfile PatientProfile { get; set; }

        public string ConditionName { get; set; }
        public string Description { get; set; }
        public DateTime DiagnosedOn { get; set; }
        public string Treatment { get; set; }
    }
}
