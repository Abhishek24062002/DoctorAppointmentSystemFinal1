﻿namespace DoctorAppointmentSystem.Models
{
    public class Appointment
    {
        public int AppointmentId { get; set; }
        public int PatientProfileId { get; set; }
        public PatientProfile PatientProfile { get; set; }
        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }
        public DateTime Date { get; set; }
        public string TimeSlot { get; set; }
        public string Status { get; set; }
        public decimal Fee { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public bool IsPaid { get; set; } = false;
        public int? StaffId { get; set; }
        public Staff Staff { get; set; }
    }

}
