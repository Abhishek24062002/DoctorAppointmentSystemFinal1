﻿using System.Text.Json.Serialization;

namespace DoctorAppointmentSystem.Models
{
    public class Role
    {
        public int RoleId { get; set; }
        public string Name { get; set; }

        [JsonIgnore]
        public ICollection<User> Users { get; set; }
    }
}
