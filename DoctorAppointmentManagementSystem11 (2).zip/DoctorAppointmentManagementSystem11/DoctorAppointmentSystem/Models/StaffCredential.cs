﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoctorAppointmentSystem.Models
{
    public class StaffCredential
    {
        [Key]
        public int StaffId { get; set; }
        public string Email { get; set; }

        [ForeignKey("StaffId")]
        public Staff Staff { get; set; }
    }

}
