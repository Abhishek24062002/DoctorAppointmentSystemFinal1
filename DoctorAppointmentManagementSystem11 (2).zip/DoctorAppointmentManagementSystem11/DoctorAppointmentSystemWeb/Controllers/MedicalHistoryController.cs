﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [ApiController]
    [Route("api/medical-history")]
    public class MedicalHistoryController : ControllerBase
    {
        private readonly IMedicalHistoryService _service;

        public MedicalHistoryController(IMedicalHistoryService service)
        {
            _service = service;
        }

        // Patient adds medical history
        [Authorize(Roles = "Patient")]
        [HttpPost("{patientProfileId}")]
        public async Task<IActionResult> AddHistory(int patientProfileId, [FromBody] MedicalHistoryDto dto)
        {
            await _service.AddMedicalHistoryAsync(patientProfileId, dto);
            return Ok("Medical history added.");
        }

        //  Anyone (Patient, Doctor, Staff) fetches history
        [Authorize(Roles = "Patient,Doctor,Staff")]
        [HttpGet("{patientProfileId}")]
        public async Task<IActionResult> GetHistory(int patientProfileId)
        {
            var history = await _service.GetMedicalHistoryAsync(patientProfileId);
            return Ok(history);
        }
    }

}