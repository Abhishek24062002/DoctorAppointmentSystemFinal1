﻿using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorSearchController : ControllerBase
    {
        private readonly IDoctorSearchService _service;

        public DoctorSearchController(IDoctorSearchService service)
        {
            _service = service;
     
        }

        //  Admin Get all doctors
        [Authorize(Roles = "Admin")]
        [HttpGet("admin/all")]
        public async Task<IActionResult> GetAllDoctors()
        {
            var doctors = await _service.GetAllDoctorsAsync();
            return Ok(doctors);
        }

        //  Public Get all doctors
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var doctors = await _service.GetAllDoctorsAsync();
            return Ok(doctors);
        }


        //  Public: Search doctor
        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string? name, [FromQuery] string? location, [FromQuery] string? speciality)
        {
            var results = await _service.SearchDoctorsAsync(name, location, speciality);
            return Ok(results);
        }



    }
}
