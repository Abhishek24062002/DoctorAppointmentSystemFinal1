﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorScheduleController : ControllerBase
    {
        private readonly IDoctorScheduleService _service;

        public DoctorScheduleController(IDoctorScheduleService service)
        {
            _service = service;
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var doctor = await _service.GetDoctorByIdWithSlotsAsync(id);
            return doctor == null ? NotFound() : Ok(doctor);
        }



        [Authorize(Roles = "Doctor")]
        [HttpPost("timeslots")]
        public async Task<IActionResult> AddTimeSlots([FromBody] List<CreateDoctorTimeSlotDto> slots)
        {
            var doctorIdStr = User.FindFirst("DoctorId")?.Value;
            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid doctor ID");

            await _service.AddTimeSlotsAsync(doctorId, slots);
            return Ok("Time slots added.");
        }

        [Authorize(Roles = "Doctor")]
        [HttpGet("timeslots-doctor")]
        public async Task<IActionResult> GetOwnTimeSlots()
        {
            var doctorIdStr = User.FindFirst("DoctorId")?.Value;
            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid doctor ID");

            var slots = await _service.GetOwnTimeSlotsAsync(doctorId);
            return Ok(slots);
        }

        [Authorize(Roles = "Doctor")]
        [HttpPut("timeslots")]
        public async Task<IActionResult> UpdateSlot([FromBody] UpdateDoctorTimeSlotDto dto)
        {
            var doctorIdStr = User.FindFirst("DoctorId")?.Value;
            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid doctor ID");

            var result = await _service.UpdateTimeSlotAvailabilityAsync(doctorId, dto);
            return result ? Ok("Updated") : NotFound("Slot not found.");
        }

        [Authorize(Roles = "Doctor")]
        [HttpDelete("timeslots/{id}")]
        public async Task<IActionResult> DeleteSlot(int id)
        {
            var doctorIdStr = User.FindFirst("DoctorId")?.Value;
            if (!int.TryParse(doctorIdStr, out int doctorId))
                return Unauthorized("Invalid doctor ID");

            var result = await _service.DeleteTimeSlotAsync(doctorId, id);
            return result ? Ok("Deleted") : NotFound("Slot not found.");
        }
    }
}
