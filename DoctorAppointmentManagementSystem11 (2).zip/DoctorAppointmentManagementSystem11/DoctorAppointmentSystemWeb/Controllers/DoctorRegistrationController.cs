﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorRegistrationController : ControllerBase
    {
        private readonly IDoctorRegistrationService _service;

        public DoctorRegistrationController(IDoctorRegistrationService service)
        {
            _service = service;
        }

        // 🔐 Admin: Register doctor
        [Authorize(Roles = "Admin")]
        [HttpPost("register")]
        public async Task<IActionResult> RegisterDoctor(DoctorRegisterDto dto)
        {
            var id = await _service.RegisterDoctorAsync(dto);
            return Ok(new { doctorId = id, message = "Doctor registered successfully." });
        }

        //Credential Registration for Doctor
        [Authorize(Roles = "Admin")]
        [HttpPost("register-Doctor-credential")]
        public async Task<IActionResult> RegisterDoctorCredential(RegisterDoctorCredentialDto dto)
        {
            var result = await _service.RegisterDoctorCredentialAsync(dto);
            if (!result) return BadRequest("Doctor credential already exists or invalid DoctorId");

            return Ok("Doctor login created successfully and linked to user system.");
        }

        //Update:
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDoctor(int id, DoctorUpdateDto dto)
        {
            var updated = await _service.UpdateDoctorAsync(id, dto);
            return updated ? Ok("Doctor updated successfully.") : NotFound("Doctor not found.");
        }

        // 🔐 Admin: Delete doctor
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDoctor(int id)
        {
            var deleted = await _service.DeleteDoctorAsync(id);
            return deleted ? Ok("Doctor deleted successfully.") : NotFound("Doctor not found.");
        }

    }
}
