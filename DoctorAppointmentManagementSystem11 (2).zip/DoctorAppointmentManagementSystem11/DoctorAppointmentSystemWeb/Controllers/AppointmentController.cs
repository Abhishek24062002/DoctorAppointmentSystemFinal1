﻿
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.DTOs.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace DoctorAppointmentManagementSystem.DoctorAppointmentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointmentService _service;
        private readonly IPaymentService _paymentService;

        public AppointmentController(IAppointmentService service, IPaymentService paymentService)
        {
            _service = service;
            _paymentService = paymentService;
        }

        [Authorize(Roles = "Patient")]
        [HttpPost("book")]
        public async Task<IActionResult> Book(CreateAppointmentDto dto)
        {
            var id = await _service.BookAppointmentAsync(dto);
            return Ok(new { appointmentId = id });
        }

        [Authorize(Roles = "Patient")]
        [HttpPost("reschedule")]
        public async Task<IActionResult> Reschedule(RescheduleAppointmentDto dto)
        {
            var result = await _service.RescheduleAsync(dto);
            return result ? Ok("Rescheduled") : NotFound();
        }

        [Authorize(Roles = "Patient")]
        [HttpDelete("cancel/{id}")]
        public async Task<IActionResult> Cancel(int id)
        {
            var result = await _service.CancelAsync(id);
            return result ? Ok("Cancelled") : NotFound();
        }

        [Authorize(Roles = "Patient")]
        [HttpGet("history/{patientId}")]
        public async Task<IActionResult> History(int patientId)
        {
            var appointments = await _service.GetAppointmentsByPatientId(patientId);
            return Ok(appointments);
        }




        [Authorize(Roles = "Patient")]
        [HttpGet("history")]
        public async Task<IActionResult> History()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var profile = await _service.GetPatientProfileByUserIdAsync(userId);

            if (profile == null)
                return NotFound("No patient profile found for the current user.");

             var appointments = await _service.GetAppointmentsByPatientId(profile.PatientProfileId);
             return Ok(appointments);
    }


        [Authorize(Roles = "Admin")]
        [HttpGet("all-history")]
        public async Task<IActionResult> GetAllHistory()
        {
            var allAppointments = await _service.GetAllAppointmentsAsync();
            return Ok(allAppointments);
        }



        [Authorize(Roles = "Patient")]
        [HttpPost("make-payment/{id}")]
        public async Task<IActionResult> MakePayment(int id, [FromQuery] decimal amount)
        {
            var paid = await _paymentService.ProcessPaymentAsync(id, amount);
            return paid
                ? Ok("Payment successful, appointment confirmed.")
                : BadRequest("Payment failed or invalid appointment.");
        }

        [Authorize(Roles = "Patient")]
        [HttpPost("pay/{id}")]
        public async Task<IActionResult> Pay(int id)
        {
            var success = await _service.MarkAsPaidAsync(id);
            return success ? Ok("Payment successful, appointment confirmed.") : NotFound();
        }



    }
}
