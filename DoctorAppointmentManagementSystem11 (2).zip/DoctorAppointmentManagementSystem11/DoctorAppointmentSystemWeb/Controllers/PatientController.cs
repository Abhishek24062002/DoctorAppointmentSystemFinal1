﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IPatientService _service;

        public PatientController(IPatientService service)
        {
            _service = service;
        }

        [Authorize(Roles = "Patient")]
        [HttpPost("create")]
        public async Task<IActionResult> Create([FromForm] PatientProfileDto dto, IFormFile medicalHistory)
        {
            // Get the logged-in user's ID from claims
            var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userIdString))
                return Unauthorized("User ID not found in token.");

            // Convert string to Guid
            if (!Guid.TryParse(userIdString, out Guid userId))
                return Unauthorized("Invalid user ID format.");

            // Pass userId to the service
            var profileId = await _service.CreatePatientProfileAsync(dto, medicalHistory, userId);

            return Ok(new { profileId });
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var profiles = await _service.GetAllProfilesAsync();
            return Ok(profiles);
        }

        [Authorize(Roles = "Patient,Doctor")]
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var profile = await _service.GetProfileByIdAsync(id);
            return profile == null ? NotFound() : Ok(profile);
        }
    }
}
    

