﻿using DoctorAppointmentSystem.Data;
using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [ApiController]
    [Route("api/account")]
    public class AccountController : ControllerBase
    {
        private readonly AppDbContext _ctx;
        private readonly IAuthService _authService;

        public AccountController(AppDbContext ctx, IAuthService authService)
        {
            _ctx = ctx;
            _authService = authService;
        }

        [Authorize(Roles = "Patient")]
        [HttpDelete("delete")]
        public async Task<IActionResult> DeleteAccount([FromBody] DeleteAccountDto dto)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = await _ctx.Users.FindAsync(Guid.Parse(userId));

            if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
                return Unauthorized("Invalid password.");

            // Remove patient profiles
            var profiles = _ctx.PatientProfiles.Where(p => p.Mobile == user.Email);
            _ctx.PatientProfiles.RemoveRange(profiles);

            // Remove appointments
            var appointments = _ctx.Appointments.Where(a => profiles.Select(p => p.PatientProfileId).Contains(a.PatientProfileId));
            _ctx.Appointments.RemoveRange(appointments);

            _ctx.Users.Remove(user);
            await _ctx.SaveChangesAsync();

            return Ok("User account deleted successfully.");
        }
    }

}
//Guid is  a 128-bit value used to identify something uniquely