﻿using DoctorAppointmentSystem.DTOs;
using DoctorAppointmentSystem.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorAppointmentSystemWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminUserController : ControllerBase
    {
        public IAdminUserService _adminService;

        public AdminUserController(IAdminUserService adminUserService)
        {
            _adminService = adminUserService;
        }


        [Authorize(Roles = "Admin")]
        [HttpGet("users")]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await _adminService.GetAllUsersAsync();
            return Ok(users);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("users/{id}")]
        public async Task<IActionResult> GetUserById(Guid id)
        {
            var user = await _adminService.GetUserByIdAsync(id);
            if (user == null) return NotFound("User not found.");
            return Ok(user);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("users/{id}")]
        public async Task<IActionResult> UpdateUser(Guid id, [FromBody] UserUpdateDto dto)
        {
            var updated = await _adminService.UpdateUserAsync(id, dto);
            if (!updated) return NotFound("User not found.");
            return Ok("User updated successfully.");
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("users/{id}")]
        public async Task<IActionResult> DeleteUser(Guid id)
        {
            var deleted = await _adminService.DeleteUserAsync(id);
            if (!deleted) return NotFound("User not found.");
            return Ok("User deleted permanently.");
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("users/search")]
        public async Task<IActionResult> SearchUsers([FromQuery] string? email, [FromQuery] string? role)
        {
            var users = await _adminService.SearchUsersAsync(email, role);
            return Ok(users);
        }
    }
}
